"""Native task, source identity and stored-horizon contracts for this study."""

import json
from dataclasses import dataclass
from pathlib import Path

from revision.audit_sources import sha256
from revision.protocol import validate_buffer


@dataclass(frozen=True)
class TaskSpec:
    native_id: str
    family: str
    horizon: int
    observation_dim: int
    goal_dim: int
    action_dim: int
    stored_observation_offset: int
    success_threshold: float

    @property
    def source_zero_name(self):
        return "expert" if self.stored_observation_offset == 0 else "trained_policy"


TASKS = {"FetchPush": TaskSpec("FetchPush-v1", "fetch", 50, 25, 3, 4, 0, .05),
         "PointMaze": TaskSpec("PointMaze_Medium-v3", "maze", 600, 4, 2, 2, 0, .45),
         "FetchSlide": TaskSpec("FetchSlide-v1", "fetch", 50, 25, 3, 4, 1, .05),
         "PointMazeLarge": TaskSpec("PointMaze_Large-v3", "maze", 800, 4, 2, 2, 1, .45)}


def task_spec(task):
    if task not in TASKS:
        raise ValueError("Unknown native task; no fallback or automatic environment substitution")
    return TASKS[task]


def validate_task_buffer(data, task):
    spec = task_spec(task)
    schema = validate_buffer(data)
    if schema["observations_per_episode"] != spec.horizon + spec.stored_observation_offset:
        raise ValueError("Stored buffer horizon disagrees with the declared collection schema")
    dimensions = {"o": spec.observation_dim, "ag": spec.goal_dim, "g": spec.goal_dim, "u": spec.action_dim}
    if any(data[key].shape[-1] != value for key, value in dimensions.items()):
        raise ValueError("Stored task feature dimensions disagree with the native task")
    schema.update(native_horizon=spec.horizon,
                  stored_scope="H observations/H-1 transitions" if spec.stored_observation_offset == 0 else "H+1 observations/H complete transitions")
    return schema


def source_catalog(config):
    spec = task_spec(config["task"])
    root = Path(config["root"])
    if spec.stored_observation_offset == 0:
        inventory = json.loads((root / "audit/source_inventory.json").read_text())
        if inventory.get("status") != "complete":
            raise ValueError("Original source audit must be complete")
        expected = {row["path"]: row for row in inventory["sources"]}
        filename = "fetch_buffer.pkl" if spec.family == "fetch" else "buffer.pkl"
        paths = [Path(config["original"]) / "offline_data" / source / filename for source in ("expert", "random")]
        rows = []
        for name, path in zip(("expert", "random"), paths):
            if str(path) not in expected or sha256(path) != expected[str(path)]["sha256"]:
                raise ValueError("Original source hash changed")
            rows.append(dict(path=path, sha256=expected[str(path)]["sha256"], source_name=name,
                             collector_training_provenance_verified=False, expert_quality_certified=False))
        return rows
    variant = config.get("source_variant", "full_v14")
    if variant not in ("full_v14", "smoke_v14"):
        raise ValueError("Unknown new-task source variant")
    if variant == "smoke_v14" and config["stage"] not in ("smoke", "modern_smoke"):
        raise ValueError("Tiny collector smoke sources are only valid for learner interface smokes")
    rows = []
    for method, name, policy in (("collector_ddpg", "trained_policy", "trained_ddpg_her"),
                                 ("collector_random", "random", "uniform_random_actions")):
        prefix = "source-smoke" if variant == "smoke_v14" else "source-full"
        folder = root / "source_collection_v14/runs" / f"{prefix}-v14-{config['task']}-{method}"
        if not all((folder / key).is_file() for key in ("config.json", "collector_manifest.json", "result.json", "buffer.pkl")):
            raise ValueError("Required new-task collector is not complete; no source fallback")
        collector = json.loads((folder / "config.json").read_text())
        report = json.loads((folder / "collector_manifest.json").read_text())
        result = json.loads((folder / "result.json").read_text())
        path = folder / "buffer.pkl"
        digest = sha256(path)
        if digest != report.get("buffer_sha256") or digest != result.get("data_sha256"):
            raise ValueError("New collector source hash changed")
        if (result.get("status") != "complete" or result.get("id") != folder.name or
                result.get("updates") != collector["updates"] or report.get("task") != config["task"] or
                report.get("source") != policy or report.get("final_policy_updates") != collector["updates"] or
                result.get("config_sha256") != sha256(folder / "config.json") or
                result.get("report_sha256") != sha256(folder / "collector_manifest.json")):
            raise ValueError("Collector provenance identity or budget changed")
        if method == "collector_ddpg" and (not (folder / "collector_final.pt").is_file() or
                report.get("collector_checkpoint_sha256") != sha256(folder / "collector_final.pt")):
            raise ValueError("Collector final model identity changed")
        rows.append(dict(path=path, sha256=digest, source_name=name,
                         collector_config_sha256=result["config_sha256"], collector_report_sha256=result["report_sha256"],
                         collector_checkpoint_sha256=report.get("collector_checkpoint_sha256"),
                         collector_training_provenance_verified=True, expert_quality_certified=False,
                         source_variant=variant, historical_collection_reconstructed=False))
    return rows
