"""Modern-method calibration on the audited historical tasks, not final effects."""

import argparse
import hashlib
import importlib.metadata
import json
import os
import pickle
import time
from pathlib import Path

import gymnasium as gym
import gymnasium_robotics  # noqa: F401
import jax
import numpy as np

from revision.audit_sources import sha256
from revision.control_dataset import selection_for_config, control_exposure_summary
from revision.episode_evaluation import evaluate_policy
from revision.frozen_experiment import validate_frozen_job, save_at_checkpoint
from revision.modern_agent import ModernAgent
from revision.modern_data import EpisodeSampler, ReferenceNormalizer
from revision.job_checkpoint import digest as scientific_digest, scientific_config, snapshot, restore, load_checkpoint
from revision.protocol import mixture_indices
from revision.task_catalog import task_spec, source_catalog, validate_task_buffer
from revision.queue import stamp, write_json


def evaluate(agent, env, count, update, output, normalizer, bank=None, role="validation"):
    def policy(observation):
        obs, goal = observation["observation"], observation["desired_goal"]
        if normalizer is not None:
            obs, goal = normalizer.observations(obs), normalizer.goals(goal)
        return agent.action(obs.astype(np.float32), goal.astype(np.float32))
    return evaluate_policy(policy, env, count, update, output, bank=bank, role=role)


def save_checkpoint(path, agent, sampler, update, identity, metrics, evaluation_path):
    state = snapshot(agent, sampler, update, identity, metrics, evaluation_path)
    temporary = path.with_suffix(".tmp")
    with temporary.open("wb") as stream:
        pickle.dump(state, stream, protocol=pickle.HIGHEST_PROTOCOL)
    os.replace(temporary, path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--resume-checkpoint", type=Path)
    opts = parser.parse_args()
    cfg = json.loads(opts.config.read_text())
    run_dir = opts.config.parent
    started = time.monotonic()
    config_hash = sha256(opts.config)
    if any((run_dir / name).exists() for name in ("runtime.json", "result.json", "validation_episodes.jsonl", "test_episodes.jsonl")):
        raise ValueError("Attempt directory contains existing evidence; use a distinct new attempt")
    frozen = validate_frozen_job(cfg) if cfg["stage"] in ("confirmatory", "frozen_runner_validation") else None
    if cfg["stage"] not in ("modern_smoke", "modern_calibration", "modern_validation", "modern_control_validation") and frozen is None:
        raise ValueError("Confirmatory jobs require a separately frozen protocol")
    if opts.resume_checkpoint and (frozen is not None or cfg.get("purpose", "").startswith("confirmatory")):
        raise ValueError("Production resume has not passed strict validation")
    if cfg["normalization"] not in ("none", "reference_support"):
        raise ValueError("Unknown normalization policy")
    if not any(device.platform == "gpu" for device in jax.devices()):
        raise RuntimeError("GPU required; do not silently fall back to CPU")
    spec = task_spec(cfg["task"])
    env = gym.make(spec.native_id)
    if env.spec.max_episode_steps != spec.horizon:
        raise ValueError("Native task horizon changed")
    initial, _ = env.reset(seed=cfg["seed"])
    pools, provenance = [], []
    for source in source_catalog(cfg):
        path = source["path"]
        with path.open("rb") as stream:
            pool = pickle.load(stream)
        schema = validate_task_buffer(pool, cfg["task"])
        pools.append(pool)
        provenance.append(dict(**{key: value for key, value in source.items() if key != "path"}, path=str(path), **schema))
    ids = mixture_indices(len(pools[0]["o"]), len(pools[1]["o"]), cfg["episodes"], cfg.get("source_zero_fraction", .5), cfg["data_seed"])
    ids, control = selection_for_config(cfg, ids)
    if any(np.any(ids[ids[:, 0] == source, 1] >= len(pools[source]["o"])) for source in (0, 1)):
        raise ValueError("Control indexes lie outside the original source pools")
    data = {}
    for key in ("o", "ag", "g", "u"):
        data[key] = np.empty((len(ids), *pools[0][key].shape[1:]), dtype=np.float32)
        if pools[0][key].shape[1:] != pools[1][key].shape[1:]:
            raise ValueError("Source schemas disagree")
        for source in (0, 1):
            mask = ids[:, 0] == source
            data[key][mask] = pools[source][key][ids[mask, 1]]
    del pools
    if (data["o"].shape[-1] != len(initial["observation"]) or
            data["g"].shape[-1] != len(initial["desired_goal"]) or
            data["u"].shape[-1] != env.action_space.shape[0]):
        raise ValueError("Task state/goal/action contract mismatch")
    if np.max(np.abs(data["u"])) > 1.000001:
        raise ValueError("Actions outside the reference normalized action range")
    data_hash = hashlib.sha256(ids.tobytes() + "".join(p["sha256"] for p in provenance).encode()).hexdigest()
    if control is not None:
        data_hash = scientific_digest(dict(source_selection=data_hash, control=control.metadata))
        np.savez_compressed(run_dir / "control_view.npz", episode_probabilities=control.probabilities,
                            slot_indices=control.slot_indices if control.slot_indices is not None else np.array([], dtype=int))
    np.savez_compressed(run_dir / "episode_ids.npz", source=ids[:, 0], episode=ids[:, 1])
    write_json(run_dir / "data_manifest.json", dict(sources=provenance, selection_sha256=data_hash,
               loaded_episodes=len(ids), unique_ids=len(np.unique(ids, axis=0)), data_seed=cfg["data_seed"],
               source_counts={spec.source_zero_name: int((ids[:, 0] == 0).sum()), "random": int((ids[:, 0] == 1).sum())},
               control=control.metadata if control is not None else None,
               conversion="Stored float64 source -> float32 model adapter; original source hash retained"))
    probabilities = control.probabilities if control is not None else np.ones(len(ids)) / len(ids)
    normalizer = ReferenceNormalizer.fit(data, probabilities) if cfg["normalization"] == "reference_support" else None
    sampler = EpisodeSampler(data, ids[:, 0], probabilities, cfg["seed"],
                             spec.success_threshold, normalizer)
    examples = sampler.initial_examples()
    agent = ModernAgent.create(cfg["method"], cfg["seed"], examples["observations"], examples["goals"], examples["actions"],
                               cfg["updates"], batch_size=cfg["batch_size"])
    code_root = Path(__file__).resolve().parents[1]
    code_hashes = {str(p.relative_to(code_root)): sha256(p) for p in sorted((code_root / "revision").rglob("*.py"))}
    packages = {dist.metadata["Name"]: dist.version for dist in importlib.metadata.distributions()}
    identity = scientific_digest(dict(config=scientific_config(cfg), data=data_hash,
                           code=code_hashes, packages=packages, agent_config=agent.config))
    metrics, start_update = [], 0
    parent = None
    if opts.resume_checkpoint:
        state, prefix = load_checkpoint(opts.resume_checkpoint)
        if state["updates"] > cfg["updates"]:
            raise ValueError("Checkpoint exceeds configured budget")
        recovered = restore(state, agent, sampler, identity)
        metrics, start_update = recovered["metrics"], recovered["updates"] + 1
        (run_dir / "validation_episodes.jsonl").write_bytes(prefix)
        parent = dict(path=str(opts.resume_checkpoint.resolve()), sha256=sha256(opts.resume_checkpoint),
                      update=state["updates"], evaluation_prefix_bytes=len(prefix))
    frozen_metadata = {key: value for key, value in frozen.items() if key != "bank"} if frozen else None
    write_json(run_dir / "runtime.json", dict(config_sha256=config_hash, code_hashes=code_hashes,
               packages=packages, agent_config=agent.config, env_spec=str(env.spec), pid=os.getpid(),
               cpu_affinity=sorted(os.sched_getaffinity(0)), jax_devices=[str(d) for d in jax.devices()],
               validation_bank_start=900000, normalization=normalizer.as_dict() if normalizer else "none (reference native default)",
               initialization_episode=examples["episode"], initialization_support_probability=float(sampler.p[examples["episode"]]),
               adapters_documented_in="revision/vendor/ADAPTATIONS.md", scientific_identity=identity,
               parent_checkpoint=parent, control=control.metadata if control is not None else None,
               frozen_protocol=frozen_metadata, final_bank_sha256=frozen["bank"].sha256 if frozen else None,
               checkpoint_policy=cfg.get("checkpoint_policy", "all_evaluated"), not_confirmatory=not bool(frozen and frozen["confirmatory"])))
    print(f"{stamp()} {cfg['id']} exact data={data_hash}; goals={data['g'].shape[-1]} state={data['o'].shape[-1]}", flush=True)
    for update in range(start_update, cfg["updates"] + 1):
        if update:
            if cfg["method"] == "smore":
                batch, auxiliary, _ = sampler.sample_smore(cfg["batch_size"], agent.config["p_future"])
            else:
                batch, _ = sampler.sample_ogbench(cfg["batch_size"], agent.config, cfg["method"] == "hiql")
                auxiliary = None
            info = agent.update(batch, auxiliary)
            if update % 100 == 0 or update == 1 or update == cfg["updates"]:
                losses = {key: float(np.mean(np.asarray(value))) for key, value in info.items()}
                if not all(np.isfinite(np.asarray(value)).all() for value in info.values()):
                    raise FloatingPointError("Non-finite loss/diagnostic; retain this attempt")
                write_json(run_dir / "progress.json", dict(status="running", updates=update,
                    total_updates=cfg["updates"], last_update=stamp(), elapsed_seconds=time.monotonic() - started,
                    losses=losses, exposure=sampler.exposure_summary(), validation=metrics))
        if update % cfg["eval_interval"] == 0 or update == cfg["updates"]:
            result = evaluate(agent, env, cfg["eval_rollouts"], update,
                              run_dir / "validation_episodes.jsonl", normalizer)
            metrics.append(dict(updates=update, **result))
            if save_at_checkpoint(cfg, update, cfg["updates"]):
                save_checkpoint(run_dir / f"checkpoint_update{update:07d}.pkl", agent, sampler,
                                update, identity, metrics, run_dir / "validation_episodes.jsonl")
            print(f"{stamp()} {cfg['id']} updates={update} validation={result}", flush=True)
    final_evaluation = None
    if frozen is not None:
        final_evaluation = evaluate(agent, env, len(frozen["bank"].seeds), cfg["updates"],
            run_dir / "test_episodes.jsonl", normalizer, bank=frozen["bank"],
            role="final_test" if frozen["confirmatory"] else "implementation_test")
    env.close()
    np.savez_compressed(run_dir / "sampling_exposure.npz", **sampler.exposure)
    exposure = control_exposure_summary(control, sampler.exposure) if control is not None else None
    write_json(run_dir / "result.json", dict(status="complete", id=cfg["id"], stage=cfg["stage"],
               seed=cfg["seed"], data_seed=cfg["data_seed"], metrics=metrics,
               updates=cfg["updates"], elapsed_seconds=time.monotonic() - started,
               config_sha256=config_hash, data_sha256=data_hash, exposure=sampler.exposure_summary(),
               scientific_identity=identity, parent_checkpoint=parent,
               control=control.metadata if control is not None else None, control_exposure=exposure,
               final_evaluation=final_evaluation, frozen_protocol=frozen_metadata,
               test_episodes_sha256=sha256(run_dir / "test_episodes.jsonl") if frozen else None,
               final_bank_sha256=frozen["bank"].sha256 if frozen else None,
               checkpoint_sha256=sha256(run_dir / f"checkpoint_update{cfg['updates']:07d}.pkl"),
               jax_memory_stats=jax.devices()[0].memory_stats(), not_confirmatory=not bool(frozen and frozen["confirmatory"])))


if __name__ == "__main__":
    main()
