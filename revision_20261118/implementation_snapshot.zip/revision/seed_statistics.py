"""Paired training-seed summaries; episodes and checkpoints never inflate n."""

from itertools import product

import numpy as np
from scipy.stats import t


def paired_seed_summary(baseline, treatment, scale=100., expected_seeds=(11, 29, 47)):
    if set(baseline) != set(treatment) or set(baseline) != set(expected_seeds):
        raise ValueError("Missing or unexpected independent seed block; do not silently drop runs")
    seeds = sorted(baseline)
    base = np.asarray([baseline[seed] for seed in seeds], dtype=np.float64)
    changed = np.asarray([treatment[seed] for seed in seeds], dtype=np.float64)
    if (base.shape != (len(seeds),) or changed.shape != base.shape or len(seeds) < 2
            or not np.isfinite(base).all() or not np.isfinite(changed).all()
            or not np.isfinite(scale) or scale <= 0):
        raise ValueError("Each seed must supply one finite endpoint in the same units")
    differences = (changed - base) * scale
    n = len(differences)
    mean, sd = float(differences.mean()), float(differences.std(ddof=1))
    radius = float(t.ppf(.975, n - 1) * sd / np.sqrt(n))
    active = differences[differences != 0]
    statistics = [abs(float(np.dot(signs, active))) for signs in product((-1., 1.), repeat=len(active))]
    observed = abs(float(active.sum()))
    tolerance = np.finfo(float).eps * 16 * max(1., observed)
    p = sum(value >= observed - tolerance for value in statistics) / len(statistics)
    return dict(seeds=seeds, independent_units=n, baseline=base.tolist(), treatment=changed.tolist(),
                scale=float(scale), differences=differences.tolist(), mean_difference=mean, sd_difference=sd,
                t95_interval=[mean - radius, mean + radius], degrees_of_freedom=n - 1,
                interval_assumption="Independent, normally distributed paired effects; not verifiable from three pairs",
                exact_sign_flip_p=float(p), nonzero_pairs=len(active),
                minimum_two_sided_exact_p=min(1., 2 / 2**len(active)),
                sign_flip_assumption="Paired effect signs are exchangeable under the null; not a demonstrated random assignment test",
                zero_observed_seed_variance=sd == 0., equivalence_demonstrated=False,
                small_n_warning="Model-based intervals and coarse exact p values cannot establish robust equivalence or absence of an effect")


def holm_adjust(p_values):
    if any(not np.isfinite(p) or not 0 <= p <= 1 for p in p_values.values()):
        raise ValueError("Invalid p value in the predeclared comparison family")
    ordered = sorted(p_values, key=p_values.get)
    adjusted, previous = {}, 0.
    for rank, key in enumerate(ordered):
        previous = max(previous, min(1., (len(ordered) - rank) * p_values[key]))
        adjusted[key] = float(previous)
    return {key: adjusted[key] for key in p_values}
