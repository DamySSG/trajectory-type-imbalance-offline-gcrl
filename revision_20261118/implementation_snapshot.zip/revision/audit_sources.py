"""Read-only schema, provenance, and quality audit of the historical source pools."""

import argparse
import hashlib
import json
import pickle
import shutil
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from revision.protocol import validate_buffer


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--original", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    records = []
    for source in ("expert", "random"):
        for filename in ("buffer.pkl", "fetch_buffer.pkl", "fetch_buffer_orig.pkl",
                         f"pointmaze_medium_{source}_20000.pkl"):
            path = args.original / "offline_data" / source / filename
            if not path.exists():
                continue
            print(f"Auditing {path}", flush=True)
            with path.open("rb") as stream:
                data = pickle.load(stream)
            row = {"path": str(path), "source": source, "sha256": sha256(path),
                   "bytes": path.stat().st_size, **validate_buffer(data)}
            delta = data["ag"][:, 1:] - data["g"]
            distances = np.linalg.norm(delta, axis=-1)
            threshold = 0.05 if data["o"].shape[-1] == 25 else 0.45
            row["descriptive_goal_tolerance"] = threshold
            row["final_distance_quantiles"] = np.quantile(distances[:, -1], [0, .25, .5, .75, 1]).tolist()
            row["final_within_tolerance"] = float(np.mean(distances[:, -1] < threshold))
            row["ever_within_tolerance"] = float(np.mean(np.any(distances < threshold, axis=1)))
            row["episodes_with_goal_changes"] = int(np.sum(np.any(np.diff(data["g"], axis=1) != 0, axis=(1, 2))))
            row["action_range"] = [float(data["u"].min()), float(data["u"].max())]
            hashes = []
            for index in range(row["episodes"]):
                h = hashlib.sha256()
                for key in ("o", "ag", "g", "u"):
                    h.update(np.ascontiguousarray(data[key][index]).tobytes())
                hashes.append(h.hexdigest())
            row["unique_content_episodes"] = len(set(hashes))
            row["duplicate_content_episodes"] = len(hashes) - len(set(hashes))
            records.append(row)
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps({"status": "in_progress", "sources": records}, indent=2))
            print(json.dumps(row), flush=True)
            del data, delta, distances
    disk = shutil.disk_usage(args.output.parent)
    args.output.write_text(json.dumps({"status": "complete", "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                                      "free_disk_bytes": disk.free, "sources": records}, indent=2))


if __name__ == "__main__":
    main()
