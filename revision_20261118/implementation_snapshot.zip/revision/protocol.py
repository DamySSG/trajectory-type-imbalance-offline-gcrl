"""Pure, tested dataset-selection rules for the revised controlled study."""

import numpy as np


def validate_buffer(data):
    if set(data) != {"o", "ag", "g", "u"}:
        raise ValueError(f"Unexpected buffer fields: {set(data)}")
    if any(not isinstance(v, np.ndarray) or v.ndim != 3 for v in data.values()):
        raise ValueError("Every field must be a three-dimensional ndarray")
    n, h, _ = data["o"].shape
    if not n or h < 2:
        raise ValueError("Empty buffer or missing transitions")
    for key, value in data.items():
        expected = h if key in ("o", "ag") else h - 1
        if value.shape[:2] != (n, expected):
            raise ValueError(f"Invalid episode/time dimensions: {key}: {value.shape}")
        for chunk in np.array_split(value, max(1, n // 500)):
            if not np.isfinite(chunk).all():
                raise ValueError(f"Non-finite observations in {key}")
    if data["ag"].shape[-1] != data["g"].shape[-1]:
        raise ValueError("Achieved and desired goal dimensions differ")
    return {"episodes": n, "observations_per_episode": h,
            "transitions_per_episode": h - 1, "transitions": n * (h - 1),
            "shapes": {k: list(v.shape) for k, v in data.items()},
            "dtypes": {k: str(v.dtype) for k, v in data.items()}}


def mixture_indices(n_expert, n_random, total, expert_fraction, seed):
    if total <= 0 or not 0 <= expert_fraction <= 1:
        raise ValueError("Invalid reference mixture")
    quotas = (round(total * expert_fraction), total - round(total * expert_fraction))
    rng = np.random.default_rng(seed)
    parts = []
    for source, (available, count) in enumerate(zip((n_expert, n_random), quotas)):
        if available < count:
            raise ValueError(f"Source {source} needs {count} unique episodes, has {available}")
        parts.append(np.column_stack((np.full(count, source),
                                      rng.choice(available, count, replace=False))))
    return rng.permutation(np.concatenate(parts).astype(np.int64))


def _strata(sources, target, target_fraction, expert_fraction):
    sources, target = np.asarray(sources), np.asarray(target, dtype=bool)
    if sources.shape != target.shape or sources.ndim != 1 or not len(sources):
        raise ValueError("Invalid source/type arrays")
    if not set(np.unique(sources)).issubset({0, 1}):
        raise ValueError("Unknown source ID")
    if not 0 <= target_fraction <= 1 or not 0 <= expert_fraction <= 1:
        raise ValueError("Fractions must be within [0, 1]")
    shares = np.array([expert_fraction, 1 - expert_fraction])
    prevalence = np.zeros(2)
    for source, share in enumerate(shares):
        mask = sources == source
        if share > 0 and not mask.any():
            raise ValueError(f"Missing source {source} with a positive quota")
        prevalence[source] = target[mask].mean() if mask.any() else 0
    minimum = float(shares[prevalence == 1].sum())
    maximum = float(shares[prevalence > 0].sum())
    if not minimum <= target_fraction <= maximum:
        raise ValueError(f"Requested prevalence outside feasible [{minimum}, {maximum}]")
    if target_fraction == minimum:
        conditional = (prevalence == 1).astype(float)
    elif target_fraction == maximum:
        conditional = (prevalence > 0).astype(float)
    else:
        interior = (prevalence > 0) & (prevalence < 1)
        log_odds = np.log(prevalence[interior]) - np.log1p(-prevalence[interior])
        conditional = prevalence.copy()
        # One shared odds multiplier preserves the natural source/type association
        # at multiplier=1. Source-specific normalizers retain fixed source mass.
        low, high = -700., 700.
        for _ in range(100):
            midpoint = (low + high) / 2
            conditional[interior] = 1 / (1 + np.exp(-np.clip(log_odds + midpoint, -700, 700)))
            if float(shares @ conditional) < target_fraction:
                low = midpoint
            else:
                high = midpoint
    for source, share in enumerate(shares):
        for selected, fraction in ((True, conditional[source]), (False, 1 - conditional[source])):
            ids = np.flatnonzero((sources == source) & (target == selected))
            mass = share * fraction
            if mass > 0 and not len(ids):
                raise ValueError(f"Infeasible nonempty quota: source={source}, target={selected}")
            yield ids, mass


def source_type_probabilities(sources, target, target_fraction, expert_fraction=0.5):
    probabilities = np.zeros(len(sources), dtype=np.float64)
    for ids, mass in _strata(sources, target, target_fraction, expert_fraction):
        if mass:
            probabilities[ids] = mass / len(ids)
    return probabilities / probabilities.sum()


def fixed_composition_indices(sources, target, total, target_fraction, expert_fraction, seed):
    if total <= 0:
        raise ValueError("Positive dataset size required")
    sources, target = np.asarray(sources), np.asarray(target, dtype=bool)
    n_expert = round(total * expert_fraction)
    n_random = total - n_expert
    n_target = round(total * target_fraction)
    strata = list(_strata(sources, target, n_target / total, n_expert / total))
    e_min = n_expert if not len(strata[1][0]) else 0
    e_max = n_expert if len(strata[0][0]) else 0
    r_min = n_random if not len(strata[3][0]) else 0
    r_max = n_random if len(strata[2][0]) else 0
    lower, upper = max(e_min, n_target - r_max), min(e_max, n_target - r_min)
    if lower > upper:
        raise ValueError("Integer source/type quotas are infeasible")
    n_expert_target = int(np.clip(round(total * strata[0][1]), lower, upper))
    n_random_target = n_target - n_expert_target
    counts = (n_expert_target, n_expert - n_expert_target,
              n_random_target, n_random - n_random_target)
    rng = np.random.default_rng(seed)
    result = []
    for (ids, _), count in zip(strata, counts):
        # Include all available IDs before allocating repeated copies when oversampling.
        copies, remaining = divmod(count, len(ids)) if len(ids) else (0, 0)
        result.extend([np.tile(ids, copies), rng.choice(ids, remaining, replace=False)])
    return rng.permutation(np.concatenate(result).astype(np.int64))
