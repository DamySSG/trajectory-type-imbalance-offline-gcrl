"""Prespecified threshold/reference sensitivities and explicit support removal."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from revision.audit_sources import sha256
from revision.balance_audit import fixed_stratified_indices, numeric_summary, stratified_probabilities
from revision.control_dataset import load_control_selection
from revision.experimental_controls import build_cohort
from revision.measurements import ternary_labels
from revision.queue import stamp, write_json


VARIANTS = ("goal_quartiles", "spatial_quartiles", "action_neutral_010", "spatial_ref500")
AXES = ("goal_separation", "spatial_support", "action_direction")
VARIANT_AXES = dict(goal_quartiles="goal_separation", spatial_quartiles="spatial_support",
                    action_neutral_010="action_direction", spatial_ref500="spatial_support")


def common_sensitivity_amplitude(reports):
    required = {(variant, task, seed) for variant in VARIANTS for task in ("FetchPush", "PointMaze")
                for seed in (1011, 1029, 1047)}
    actual = {(row["variant"], row["task"], row["data_seed"]) for row in reports}
    if actual != required or len(reports) != len(required):
        raise ValueError("Missing or duplicated registered sensitivity cohort")
    for magnitude in (.05, .025, .01):
        valid = True
        for report in reports:
            axis = VARIANT_AXES[report["variant"]]
            for sign in (-1, 1):
                rows = [row for row in report["candidate_controls"] if row["axis"] == axis and
                        row["level"] == 2 and row["control"] == "quality_cross_axis" and
                        np.isclose(row["requested_change"], sign * magnitude, rtol=0, atol=1e-12)]
                valid &= len(rows) == 1 and rows[0]["feasible"]
        if valid:
            return magnitude
    return None


def variant_labels(base, variant, nested=None):
    if variant not in VARIANTS:
        raise ValueError("Unknown prespecified measurement variant")
    n = len(base["source"])
    references = np.asarray(base["measurement_reference_ids"])
    if (references.ndim != 1 or references.dtype.kind not in "iu" or not len(references) or
            len(np.unique(references)) != len(references) or np.any(references < 0) or np.any(references >= n)):
        raise ValueError("Invalid held measurement reference")
    for key in ("score_goal_separation", "score_spatial_radius", "score_action_bias"):
        if np.asarray(base[key]).shape != (n,) or not np.isfinite(base[key]).all():
            raise ValueError("Nonfinite or incomplete measurement scores")
    result = {key: np.asarray(value).copy() for key, value in base.items()}
    axis = ("goal_separation" if variant == "goal_quartiles" else
            "action_direction" if variant == "action_neutral_010" else "spatial_support")
    thresholds = None
    if variant == "action_neutral_010":
        score = result["score_action_bias"]
        if np.any(np.abs(score) > 1):
            raise ValueError("Action tendency score lies outside its defined range")
        result["label_action_direction"] = np.where(score < -.10, 0, np.where(score > .10, 2, 1)).astype(np.int8)
        thresholds = [-.10, .10]
    else:
        key = "score_goal_separation" if axis == "goal_separation" else "score_spatial_radius"
        if variant == "spatial_ref500":
            if nested is None:
                raise ValueError("Nested held-reference scores are required")
            references = np.asarray(nested["reference_ids"])
            score = np.asarray(nested["spatial_score"])
            if (references.ndim != 1 or references.dtype.kind not in "iu" or not len(references) or
                    len(np.unique(references)) != len(references) or
                    not np.isin(references, base["measurement_reference_ids"]).all()):
                raise ValueError("Nested reference must remain within the original held exclusion pool")
            if score.shape != (n,) or not np.isfinite(score).all():
                raise ValueError("Incomplete nested spatial scores")
            result[key] = score.copy()
        quantiles = [1/3, 2/3] if variant == "spatial_ref500" else [.25, .75]
        thresholds = np.quantile(result[key][references], quantiles).tolist()
        result["label_" + axis] = ternary_labels(result[key], thresholds)
    report = dict(variant=variant, changed_axis=axis, thresholds=thresholds,
        threshold_reference_episodes=len(references),
        training_exclusion_reference_episodes=len(base["measurement_reference_ids"]),
        threshold_reference_ids_sha256=hashlib.sha256(references.tobytes()).hexdigest(),
        changed_labels_fraction=float((result["label_" + axis] != base["label_" + axis]).mean()),
        other_axes_unchanged=True, source_quality_and_episode_mapping_unchanged=True,
        policy_results_used=False, construct_validity_certified=False,
        nested_reference_changes_scaling_scores_and_thresholds=(variant == "spatial_ref500"))
    return result, report


def removal_cohort(labels_path, base_folder, output, task, data_seed):
    labels_path, base_folder, output = map(Path, (labels_path, base_folder, output))
    original = json.loads((base_folder / "audit.json").read_text())
    if (original["task"], original["data_seed"], original["source_label_artifact_sha256"]) != (
            task, data_seed, sha256(labels_path)) or not original["reference_disjoint"]:
        raise ValueError("Removal must use the recorded original cohort and labels")
    output.mkdir(parents=True, exist_ok=False)
    with np.load(base_folder / "cohort.npz", allow_pickle=False) as raw:
        cohort = {key: raw[key].copy() for key in raw.files}
    ids, sources = cohort["global_ids"], cohort["source"]
    if hashlib.sha256(ids.tobytes()).hexdigest() != original["cohort_global_ids_sha256"]:
        raise ValueError("Original cohort hash changed")
    with np.load(labels_path, allow_pickle=False) as raw:
        labels = {axis: raw["label_" + axis][ids] for axis in AXES}
        quality = {key.removeprefix("quality_"): raw[key][ids] for key in raw.files if key.startswith("quality_")}
        if (np.intersect1d(ids, raw["measurement_reference_ids"]).size or
                not np.array_equal(raw["source"][ids], sources) or
                not np.array_equal(raw["source_episode"][ids], cohort["source_episode"])):
            raise ValueError("Removal source mapping or reference exclusion changed")
    np.savez_compressed(output / "cohort.npz", **cohort)
    rows, n = [], len(ids)
    quota = np.bincount(sources, minlength=2)
    for index, axis in enumerate(AXES):
        target = labels[axis] == 2
        row = dict(axis=axis, level=2, control="source_only", natural_fraction=float(target.mean()),
                   requested_change=-float(target.mean()), requested_fraction=0., request_not_clipped=True,
                   request_type="complete_upper_type_removal")
        try:
            probabilities, weighted = stratified_probabilities(sources, target, 0.)
            indices, fixed = fixed_stratified_indices(sources, target, 0., data_seed + 20000 + index)
        except ValueError as error:
            rows.append(dict(**row, feasible=False, reason=str(error)))
            continue
        if np.any(probabilities[target] > 0) or target[indices].any() or not np.array_equal(
                np.bincount(sources[indices], minlength=2), quota):
            raise ValueError("Complete removal did not preserve zero support and source quotas")
        path = output / f"{axis}_level2_source_only_removed.npz"
        np.savez_compressed(path, episode_probabilities=probabilities, indices=indices)
        rows.append(dict(**row, feasible=True, manifest=path.name, manifest_sha256=sha256(path),
            weighted=weighted, fixed=fixed, observed_change=-float(target.mean()),
            source_counts=quota.tolist(), repeated_copies=int(n - len(np.unique(indices))),
            quality_fixed={key: numeric_summary(value[indices]) for key, value in quality.items()},
            quality_weighted={key: numeric_summary(value, probabilities) for key, value in quality.items()}))
    report = dict(task=task, data_seed=data_seed, source_label_artifact_sha256=sha256(labels_path),
        cohort_global_ids_sha256=original["cohort_global_ids_sha256"], source_counts=quota.tolist(),
        reference_disjoint=True, total_episodes=n, return_thresholds=original["return_thresholds"],
        candidate_controls=rows, requested=len(rows), feasible=sum(row["feasible"] for row in rows),
        baseline_quality=original["baseline_quality"], baseline_category_counts=original["baseline_category_counts"],
        loader_views_verified=0, quality_held_fixed=False, other_axes_held_fixed=False,
        reference_cohort_sha256=sha256(base_folder / "cohort.npz"), performance_results_used=False,
        final_scientific_matrix_frozen=False, created=stamp(), code_sha256=sha256(Path(__file__)),
        limitation="Source-stratified complete upper-type removal changes unique support and may change quality, other categories and fitted moments; not a pure frequency comparison")
    write_json(output / "audit.json", report)
    for row in rows:
        if row["feasible"]:
            for arm in ("weighted", "fixed_size"):
                view = load_control_selection(output / "cohort.npz", output / row["manifest"], labels_path,
                                               arm, task, data_seed)
                if view.probabilities[view.labels[row["axis"]] == 2].sum() != 0:
                    raise ValueError("Removed type remains in the checked training view")
                report["loader_views_verified"] += 1
    write_json(output / "audit.json", report)
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--measurements", type=Path, required=True)
    parser.add_argument("--controls", type=Path, required=True)
    parser.add_argument("--references", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    variants, controls, removals, dose_reports = [], [], [], []
    for task in ("FetchPush", "PointMaze"):
        path = args.measurements / f"labels_{task}.npz"
        with np.load(path, allow_pickle=False) as raw:
            base = {key: raw[key].copy() for key in raw.files}
        nested_path = args.references / f"reference_validation_v10_{task}/reference_500.npz"
        with np.load(nested_path, allow_pickle=False) as raw:
            nested = {key: raw[key].copy() for key in raw.files}
        if not np.array_equal(np.bincount(base["source"][nested["reference_ids"]], minlength=2), [500, 500]):
            raise ValueError("Expected the independently audited500-per-source nested reference")
        for variant in VARIANTS:
            folder = args.output / "sensitivity" / variant
            folder.mkdir(parents=True, exist_ok=True)
            data, report = variant_labels(base, variant, nested)
            labels_path = folder / f"labels_{task}.npz"
            np.savez_compressed(labels_path, **data)
            report.update(task=task, primary_labels_sha256=sha256(path), labels_sha256=sha256(labels_path),
                          reference_scores_sha256=sha256(nested_path) if variant == "spatial_ref500" else None,
                          code_sha256=sha256(Path(__file__)))
            write_json(folder / f"definition_{task}.json", report)
            variants.append(report)
            for seed in (1011, 1029, 1047):
                out = folder / f"{task}_d{seed}"
                audit = build_cohort(labels_path, out, task, seed, changes=(0., -.05, .05, -.025, .025, -.01, .01))
                with np.load(args.controls / f"mixture_50/{task}_d{seed}/cohort.npz") as primary, np.load(out / "cohort.npz") as varied:
                    if not np.array_equal(primary["global_ids"], varied["global_ids"]):
                        raise ValueError("Sensitivity cohort changed instead of only its classification")
                controls.append(dict(variant=variant, task=task, data_seed=seed, requested=audit["requested"],
                                     feasible=audit["feasible"], loader_views_verified=audit["loader_views_verified"]))
                dose_reports.append(dict(variant=variant, task=task, data_seed=seed,
                                         candidate_controls=audit["candidate_controls"]))
        for seed in (1011, 1029, 1047):
            out = args.output / "sensitivity/primary" / f"{task}_d{seed}"
            audit = build_cohort(path, out, task, seed, changes=(0., -.05, .05, -.025, .025, -.01, .01))
            with np.load(args.controls / f"mixture_50/{task}_d{seed}/cohort.npz") as first, np.load(out / "cohort.npz") as last:
                if not np.array_equal(first["global_ids"], last["global_ids"]):
                    raise ValueError("Small-dose original-definition cohort changed")
            controls.append(dict(variant="primary", task=task, data_seed=seed, requested=audit["requested"],
                                 feasible=audit["feasible"], loader_views_verified=audit["loader_views_verified"]))
            audit = removal_cohort(path, args.controls / f"mixture_50/{task}_d{seed}",
                args.output / "removal" / f"{task}_d{seed}", task, seed)
            removals.append({key: audit[key] for key in ("task", "data_seed", "requested", "feasible", "loader_views_verified")})
    write_json(args.output / "summary.json", dict(created=stamp(), definitions=variants, sensitivity_controls=controls,
        removal_controls=removals, policy_results_used=False, final_scientific_matrix_frozen=False,
        common_sensitivity_amplitude=common_sensitivity_amplitude(dose_reports),
        sensitivity_dose_rule="Largest prespecified common feasible .05/.025/.01 change for both signs, upper changed-axis category, all four variants, two tasks and three data seeds; no policy outcomes"))
    print(json.dumps(dict(definitions=len(variants), sensitivity_cohorts=len(controls), removal_cohorts=len(removals),
                         policy_results_used=False)))


if __name__ == "__main__":
    main()
