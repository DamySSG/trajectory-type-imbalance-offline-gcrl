"""Bounded, disk-aware GPU queue for auditable calibration runs on server 205."""

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


def calibration_matrix():
    jobs = []
    for task in ("FetchPush", "PointMaze"):
        for method in ("gcsl", "wgcsl", "ddpg", "gofar"):
            smoke = f"smoke-{task}-{method}-s11"
            common = {"task": task, "method": method, "batch_size": 512,
                      "n_cycles": 10, "n_batches": 20, "episodes": 10000}
            jobs.append({**common, "id": smoke, "stage": "smoke", "seed": 11,
                         "data_seed": 1011, "epochs": 2, "eval_rollouts": 4,
                         "eval_interval": 1, "depends_on": []})
            for seed in (11, 29, 47):
                jobs.append({**common, "id": f"calibration-{task}-{method}-s{seed}",
                             "stage": "calibration", "seed": seed, "data_seed": 1000 + seed,
                             "epochs": 100, "eval_rollouts": 32, "eval_interval": 10,
                             "depends_on": [smoke]})
    return jobs


def eligible_jobs(jobs, states):
    return [j for j in jobs if j["id"] not in states and all(
        states.get(dep, {}).get("state") == "completed" for dep in j["depends_on"])]


def choose_gpu(free_mib, reservations, job_mib=3072, headroom_mib=4096):
    available = {g: free - reservations.get(g, 0) for g, free in free_mib.items()}
    if not available:
        return None
    gpu = max(available, key=available.get)
    return gpu if available[gpu] >= job_mib + headroom_mib else None


def stamp():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False))
    os.replace(temporary, path)


def gpu_memory():
    output = subprocess.check_output([
        "nvidia-smi", "--query-gpu=index,memory.free", "--format=csv,noheader,nounits"
    ], text=True)
    return {int(line.split(",")[0]): int(line.split(",")[1]) for line in output.splitlines()}


def run_queue(root, original, max_jobs):
    import fcntl

    root.mkdir(parents=True, exist_ok=True)
    lock = (root / "queue.lock").open("w")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    os.sched_setaffinity(0, {30, 78})
    (root / "queue.pid").write_text(str(os.getpid()))
    matrix_path = root / "calibration_matrix.json"
    if not matrix_path.exists():
        write_json(matrix_path, calibration_matrix())
    jobs = json.loads(matrix_path.read_text())
    state_path = root / "queue_state.json"
    states = json.loads(state_path.read_text())["jobs"] if state_path.exists() else {}
    # Never launch a duplicate of a surviving process after controller restart.
    for job_id, state in states.items():
        if state["state"] == "running":
            try:
                os.kill(state["pid"], 0)
            except ProcessLookupError:
                result = root / "runs" / job_id / "result.json"
                state["state"] = "completed" if result.exists() and json.loads(result.read_text()).get("status") == "complete" else "interrupted"
            else:
                raise RuntimeError(f"Surviving job {job_id}; reconcile it before restart")
    running = {}
    while True:
        for job_id, item in list(running.items()):
            process, log = item
            code = process.poll()
            if code is not None:
                log.close()
                result = root / "runs" / job_id / "result.json"
                ok = code == 0 and result.exists() and json.loads(result.read_text()).get("status") == "complete"
                states[job_id].update(state="completed" if ok else "failed", exit_code=code, finished=stamp())
                print(f"{stamp()} {job_id} {states[job_id]['state']}", flush=True)
                del running[job_id]
        disk = shutil.disk_usage(root)
        free = gpu_memory()
        for job in eligible_jobs(jobs, states):
            if len(running) >= max_jobs or disk.free < 100 * 1024**3:
                break
            # Deduct reservations as well as observed allocation, conservatively
            # covering startup races and later CUDA allocations.
            reserved = {g: 3072 * sum(states[k]["gpu"] == g for k in running) for g in free}
            gpu = choose_gpu(free, reserved)
            if gpu is None:
                break
            used_cores = {states[k]["physical_core"] for k in running}
            core = next(c for c in range(30, 48) if c not in used_cores)
            run_dir = root / "runs" / job["id"]
            run_dir.mkdir(parents=True, exist_ok=False)
            config = {**job, "original": str(original), "root": str(root),
                      "gpu": gpu, "physical_core": core, "created": stamp()}
            write_json(run_dir / "config.json", config)
            env = os.environ.copy()
            env.update(CUDA_VISIBLE_DEVICES=str(gpu), OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
                       OPENBLAS_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1", WANDB_MODE="disabled",
                       XLA_PYTHON_CLIENT_PREALLOCATE="false")
            command = ["taskset", "-c", f"{core},{core + 48}", sys.executable, "-u",
                       "-m", "revision.run_calibration", "--config", str(run_dir / "config.json")]
            log = (run_dir / "stdout.log").open("a")
            process = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT,
                                       stdin=subprocess.DEVNULL, start_new_session=True)
            running[job["id"]] = (process, log)
            states[job["id"]] = {"state": "running", "pid": process.pid, "gpu": gpu,
                                  "physical_core": core, "started": stamp(), "command": command}
            print(f"{stamp()} launched {job['id']} gpu={gpu} cpu={core},{core + 48} pid={process.pid}", flush=True)
        done = not running and not eligible_jobs(jobs, states)
        write_json(state_path, {"timestamp": stamp(), "controller_pid": os.getpid(),
                               "phase": "finished_or_blocked" if done else "running",
                               "free_disk_bytes": disk.free, "gpu_free_mib": free,
                               "max_jobs": max_jobs, "total_jobs": len(jobs), "jobs": states})
        if done:
            return
        time.sleep(15)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--original", type=Path, required=True)
    parser.add_argument("--max-jobs", type=int, default=18)
    parser.add_argument("--detach", action="store_true")
    args = parser.parse_args()
    if not 1 <= args.max_jobs <= 18:
        raise ValueError("At most 18 physical CPU slots")
    if args.detach:
        args.root.mkdir(parents=True, exist_ok=True)
        log = (args.root / "controller.log").open("a")
        command = [sys.executable, "-u", "-m", "revision.queue", "--root", str(args.root),
                   "--original", str(args.original), "--max-jobs", str(args.max_jobs)]
        process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        print(json.dumps({"controller_pid": process.pid, "log": str(args.root / "controller.log")}))
    else:
        run_queue(args.root, args.original, args.max_jobs)


if __name__ == "__main__":
    main()
