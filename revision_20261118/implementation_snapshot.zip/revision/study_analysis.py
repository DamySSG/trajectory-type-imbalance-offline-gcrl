"""Analyze complete prespecified families without treating conditions as seeds."""

import math

from revision.seed_statistics import holm_adjust, paired_seed_summary


def analyze_family(family, rows):
    endpoint = family["endpoint"]
    if endpoint not in ("final_success", "ever_success", "native_return"):
        raise ValueError("Unregistered endpoint")
    scale = 1. if endpoint == "native_return" else 100.
    contrasts = family["contrasts"]
    if not contrasts or len({row["id"] for row in contrasts}) != len(contrasts):
        raise ValueError("Empty or duplicated prespecified family")
    reports = []
    for contrast in contrasts:
        pairs = contrast["pairs"]
        if len(pairs) != 3 or {pair["seed"] for pair in pairs} != {11,29,47}:
            raise ValueError("Every contrast requires all three registered seed blocks")
        differences, points = {}, {}
        for pair in pairs:
            terms = pair.get("terms", [dict(run=pair.get("condition"), coefficient=1),
                                       dict(run=pair.get("reference"), coefficient=-1)])
            if (not terms or len({term["run"] for term in terms}) != len(terms) or
                    any(term["run"] not in rows or not math.isfinite(term["coefficient"]) for term in terms) or
                    not math.isclose(sum(term["coefficient"] for term in terms), 0., abs_tol=1e-12)):
                raise ValueError("Incomplete or invalid registered contrast terms")
            values = [rows[term["run"]] for term in terms]
            seed = pair["seed"]
            if (any(row["seed"] != seed or row["data_seed"] != seed+1000 for row in values) or
                    len({(row["task"], row["method"]) for row in values}) != 1 or
                    any(not math.isfinite(row[endpoint]) for row in values)):
                raise ValueError("Cross-seed, cross-task/method or nonfinite contrast")
            differences[seed] = sum(term["coefficient"] * rows[term["run"]][endpoint] for term in terms)
            points[seed] = {term["run"]: rows[term["run"]][endpoint] for term in terms}
        report = paired_seed_summary({seed: 0. for seed in differences}, differences, scale=scale)
        del report["baseline"], report["treatment"]
        reports.append(dict(id=contrast["id"], **report, raw_endpoints_by_seed=points,
                            registered_pairs=pairs))
    adjusted = holm_adjust({row["id"]: row["exact_sign_flip_p"] for row in reports})
    for row in reports:
        row["holm_p"] = adjusted[row["id"]]
    return dict(id=family["id"], endpoint=endpoint, contrasts=reports, registered_family_size=len(contrasts),
                multiplicity="Holm across the complete prespecified family", analysis_dropped_runs=False)
