"""Small wrappers around pinned official losses, with full optimizer snapshots."""

import collections
import importlib
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class SMOReArgs:
    grad_pen: bool = False
    lambda_gp: int = 1
    max_clip: float = 7.
    num_v_updates: int = 1


MixtureGoalBatch = collections.namedtuple("MixtureGoalBatch", (
    "observations", "actions", "next_observations", "achieved_goals", "goals", "rewards", "is_expert"))
GoalEntryBatch = collections.namedtuple("GoalEntryBatch", MixtureGoalBatch._fields[:-1])


class ModernAgent:
    @classmethod
    def create(cls, method, seed, observations, goals, actions, max_updates,
               hidden_dims=None, batch_size=None):
        if method not in ("hiql", "crl", "smore"):
            raise ValueError("Unknown modern method")
        wrapper = cls()
        wrapper.method = method
        vendor = Path(__file__).resolve().parent / "vendor"
        if method == "smore":
            sys.path.insert(0, str(vendor / "smore"))
            module = importlib.import_module("learner")
            config = importlib.import_module("configs.gcrl_config").get_config().to_dict()
            if hidden_dims is not None:
                config["hidden_dims"] = tuple(hidden_dims)
            config.update(max_steps=max_updates, loss_temp=1., double_q=True, vanilla=True,
                          alpha=.8, beta=.8, loss_type="smore_stable", opt_decay_schedule="cosine")
            wrapper.config = {**config, "batch_size": batch_size or 256, "p_future": .8,
                              "auxiliary_branch": "weighted valid goal-entry transitions",
                              "args": vars(SMOReArgs())}
            wrapper.agent = module.Learner(seed, np.concatenate((observations, goals), -1),
                                           actions, args=SMOReArgs(), **config)
        else:
            sys.path.insert(0, str(vendor / "ogbench"))
            module = importlib.import_module(f"agents.{method}")
            config = module.get_config().to_dict()
            config["encoder"] = None
            config["frame_stack"] = None
            if hidden_dims is not None:
                config.update(actor_hidden_dims=tuple(hidden_dims), value_hidden_dims=tuple(hidden_dims))
            if batch_size is not None:
                config["batch_size"] = batch_size
            wrapper.config = config
            wrapper.agent = getattr(module, "HIQLAgent" if method == "hiql" else "CRLAgent").create(
                seed, observations, actions, config, ex_goals=goals)
        return wrapper

    def update(self, batch, auxiliary=None):
        if self.method == "smore":
            return self.agent.update(MixtureGoalBatch(**batch), GoalEntryBatch(**auxiliary))
        self.agent, info = self.agent.update(batch)
        return info

    def action(self, observation, goal):
        import jax

        if self.method == "smore":
            saved = self.agent.rng
            try:
                return np.asarray(self.agent.sample_actions(np.concatenate((observation, goal)), temperature=0.))
            finally:
                self.agent.rng = saved
        return np.asarray(self.agent.sample_actions(observation, goal, seed=jax.random.PRNGKey(0), temperature=0.))

    def _state(self):
        if self.method == "smore":
            return {name: getattr(self.agent, name) for name in ("rng", "actor", "critic", "value", "target_critic")}
        return self.agent

    def state_bytes(self):
        from flax.serialization import to_bytes
        return to_bytes(self._state())

    def load_state_bytes(self, payload):
        from flax.serialization import from_bytes
        state = from_bytes(self._state(), payload)
        if self.method == "smore":
            for name, value in state.items():
                setattr(self.agent, name, value)
        else:
            self.agent = state
