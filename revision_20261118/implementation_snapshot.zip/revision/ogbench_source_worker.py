"""Fixed-budget native source producer; never a formal intervention learner."""

import argparse
import importlib.metadata
import json
import os
import pickle
import random
import shutil
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from revision.audit_sources import sha256
from revision.collector_contract import complete_rollout, seed_bank
from revision.ogbench_native import NativeGoalEnv, ENVIRONMENTS
from revision.ogbench_source_jobs import source_jobs
from revision.protocol import validate_buffer
from revision.queue import write_json, stamp


def deterministic(agent, observation):
    import torch
    with torch.no_grad():
        tensor = agent._preproc_inputs(observation['observation'], observation['desired_goal'])
        return agent._deterministic_action(tensor).detach().cpu().numpy().reshape(-1)


def create_agent(cfg, env, initial, run_dir):
    from rl_modules.ddpg_agent import DDPG
    hyper = dict(replay_strategy='future', relabel_percent=.8, buffer_size=2000000,
        clip_obs=200., clip_range=5., random_eps=.3, noise_eps=.2, gamma=.98,
        action_l2=1., lr_actor=.001, lr_critic=.001, polyak=.95, batch_size=512,
        threshold=.5 if cfg['task'] == 'AntMazeLarge' else .04, cuda=True,
        env=cfg['task'], save_dir=str(run_dir), run_name='collector_model',
        num_rollouts_per_mpi=1)
    params = dict(obs=len(initial['observation']), goal=len(initial['desired_goal']),
        action=env.action_space.shape[0], action_max=float(env.action_space.high[0]),
        action_space=env.action_space, max_timesteps=env.spec.max_episode_steps + 1)
    return DDPG(SimpleNamespace(**hyper), env, params), hyper


def save_model(agent, path, epoch, config_hash):
    import torch
    state = dict(epoch=epoch, config_sha256=config_hash, production_resume_validated=False,
        objects={key: value.state_dict() for key, value in vars(agent).items()
                 if isinstance(value, (torch.nn.Module, torch.optim.Optimizer))},
        normalizers={key: {name: value for name, value in vars(getattr(agent, key)).items()
                           if name != 'lock'} for key in ('o_norm', 'g_norm')},
        rng=dict(python=random.getstate(), numpy=np.random.get_state(),
                 torch=torch.get_rng_state(), cuda=torch.cuda.get_rng_state_all()))
    temporary = path.with_suffix('.tmp')
    torch.save(state, temporary)
    os.replace(temporary, path)


def train(agent, env, cfg, directory, started, config_hash):
    import torch
    resets = seed_bank('online_training', cfg['epochs'] * cfg['n_cycles'])
    index, updates = 0, 0
    for epoch in range(1, cfg['epochs'] + 1):
        for _ in range(cfg['n_cycles']):
            def stochastic(observation):
                with torch.no_grad():
                    value = agent._preproc_inputs(observation['observation'], observation['desired_goal'])
                    return agent._stochastic_actions(value)
            data, _ = complete_rollout(env, stochastic, resets[index])
            index += 1
            episode = [data[key][None] for key in ('o', 'ag', 'g', 'u')]
            agent.buffer.store_episode(episode)
            agent._update_normalizer(episode)
            for _ in range(cfg['n_batches']):
                agent._update_network(future_p=agent.her_module.future_p)
                updates += 1
            agent._soft_update()
        if epoch % cfg['eval_interval'] == 0 or epoch == cfg['epochs']:
            with (directory / 'collector_validation.jsonl').open('a') as stream:
                for seed in seed_bank('validation', cfg['eval_rollouts']):
                    _, row = complete_rollout(env, lambda ob: deterministic(agent, ob), seed)
                    stream.write(json.dumps(dict(epoch=epoch, **row), allow_nan=False) + '\n')
            save_model(agent, directory / f'collector_epoch{epoch:04d}.pt', epoch, config_hash)
        write_json(directory / 'progress.json', dict(phase='online_collection_and_training',
            epoch=epoch, updates=updates, total_updates=cfg['updates'], online_episodes=index,
            elapsed_seconds=time.monotonic() - started, last_update=stamp()))
        print(stamp(), cfg['id'], 'epoch', epoch, 'updates', updates, flush=True)
    if updates != cfg['updates']:
        raise ValueError('Collector optimizer budget changed')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    cfg = json.loads(args.config.read_text())
    directory = args.config.parent
    expected = next((job for job in source_jobs() if job['id'] == cfg.get('id')), None)
    if expected is None or any(cfg.get(key) != value for key, value in expected.items()):
        raise ValueError('Source task/budget/config differs from its declared matrix')
    if cfg['task'] not in ENVIRONMENTS or cfg['method'] not in ('collector_random', 'collector_ddpg'):
        raise ValueError('Unknown native source identity')
    if cfg.get('confirmatory') is not False or cfg.get('resume_allowed') is not False:
        raise ValueError('Source job cannot admit confirmatory training or resume')
    if any((directory / name).exists() for name in ('runtime.json', 'buffer.pkl', 'result.json')):
        raise ValueError('Preserve existing evidence; use a distinct technical attempt')
    started, config_hash = time.monotonic(), sha256(args.config)
    env = NativeGoalEnv(cfg['task'], collection=True)
    try:
        initial, _ = env.reset(seed=cfg['seed'])
        h, od, gd, ad = env.spec.max_episode_steps, len(initial['observation']), len(initial['desired_goal']), env.action_space.shape[0]
        raw_bytes = cfg['episodes'] * ((h + 1) * (od + gd) + h * (gd + ad)) * 8
        if shutil.disk_usage(directory).free < 100 * 1024**3 + raw_bytes:
            raise ValueError('Native source forecast would violate the disk guard')
        agent, hyper = None, None
        if cfg['method'] == 'collector_ddpg':
            import torch
            if not torch.cuda.is_available():
                raise ValueError('No assigned CUDA device; no CPU fallback')
            torch.set_num_threads(1)
            torch.set_num_interop_threads(1)
            random.seed(cfg['seed']); np.random.seed(cfg['seed'])
            torch.manual_seed(cfg['seed']); torch.cuda.manual_seed_all(cfg['seed'])
            agent, hyper = create_agent(cfg, env, initial, directory)
        code = Path(__file__).resolve().parents[1]
        code_hashes = {str(path.relative_to(code)): sha256(path) for folder in
                      ('revision', 'rl_modules', 'her_modules', 'mpi_utils')
                      for path in sorted((code / folder).rglob('*.py'))}
        write_json(directory / 'runtime.json', dict(config_sha256=config_hash,
            source_code_sha256=code_hashes, pid=os.getpid(), cpu_affinity=sorted(os.sched_getaffinity(0)),
            native_id=env.spec.id, dataset_environment=ENVIRONMENTS[cfg['task']],
            observation_dim=od, goal_dim=gd, action_dim=ad, horizon=h,
            packages={d.metadata['Name']: d.version for d in importlib.metadata.distributions()},
            raw_buffer_forecast_bytes=raw_bytes, policy_hyperparameters=hyper,
            full_state_goals=True, native_success_geometry_verified=True,
            source_origin='New controlled trained-policy/uniform-random source, not the published OGBench NPZ',
            reset_adapter='Seed global, environment and cached native stabilization action-space RNG',
            collection_termination='Continue to full native horizon; task-success signal/reward unchanged',
            confirmatory=False, expert_quality_certified=False, production_resume_validated=False))
        if agent is not None:
            train(agent, env, cfg, directory, started, config_hash)
            save_model(agent, directory / 'collector_final.pt', cfg['epochs'], config_hash)
        purpose = 'trained_collection' if agent is not None else 'random_collection'
        resets = seed_bank(purpose, cfg['episodes'])
        rng = np.random.default_rng(cfg['action_seed'])
        policy = (lambda obs: deterministic(agent, obs)) if agent is not None else (
            lambda obs: rng.uniform(env.action_space.low, env.action_space.high))
        data, final_success, ever_success, returns = None, [], [], []
        with (directory / 'collection_episodes.jsonl').open('x') as stream:
            for index, seed in enumerate(resets):
                episode, record = complete_rollout(env, policy, seed)
                if data is None:
                    data = {key: np.empty((cfg['episodes'], *value.shape), dtype=np.float64)
                            for key, value in episode.items()}
                for key in data:
                    data[key][index] = episode[key]
                final_success.append(record['final_success'])
                ever_success.append(record['ever_success'])
                returns.append(record['native_return'])
                stream.write(json.dumps(dict(episode=index, **record), allow_nan=False) + '\n')
                if (index + 1) % 100 == 0 or index + 1 == cfg['episodes']:
                    stream.flush()
                    write_json(directory / 'progress.json', dict(phase='offline_source_collection',
                        collected=index + 1, total=cfg['episodes'], updates=cfg['updates'],
                        elapsed_seconds=time.monotonic() - started, last_update=stamp()))
                    print(stamp(), cfg['id'], 'collected', index + 1, flush=True)
        schema = validate_buffer(data)
        temporary = directory / 'buffer.tmp'
        with temporary.open('xb') as stream:
            pickle.dump(data, stream, protocol=pickle.HIGHEST_PROTOCOL)
        os.replace(temporary, directory / 'buffer.pkl')
        manifest = dict(task=cfg['task'], source='trained_ddpg_her' if agent is not None else 'uniform_random_actions',
            schema=schema, buffer_sha256=sha256(directory / 'buffer.pkl'),
            native_rewards_recorded=True, actual_fixed_desired_goals_recorded=True,
            full_native_horizon=True, checkpoint_selection='Final fixed-budget policy only',
            final_policy_updates=cfg['updates'], reset_seeds=resets.tolist(),
            final_success=float(np.mean(final_success)), ever_success=float(np.mean(ever_success)),
            native_return_mean=float(np.mean(returns)), expert_quality_certified=False,
            checkpoint_sha256=sha256(directory / 'collector_final.pt') if agent is not None else None)
        write_json(directory / 'collector_manifest.json', manifest)
        write_json(directory / 'result.json', dict(status='complete', id=cfg['id'],
            updates=cfg['updates'], config_sha256=config_hash,
            data_sha256=manifest['buffer_sha256'], report_sha256=sha256(directory / 'collector_manifest.json'),
            episodes=cfg['episodes'], native_horizon=h, elapsed_seconds=time.monotonic() - started,
            not_confirmatory=True, independent_source_audit_pending=True))
    finally:
        env.close()


if __name__ == '__main__':
    main()
