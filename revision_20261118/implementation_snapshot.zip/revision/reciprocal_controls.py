"""Exchange low/high composition while retaining every middle episode's mass."""

import numpy as np

from revision.balance_audit import fixed_stratified_indices, stratified_probabilities


def _inputs(strata, labels, change):
    strata, labels = np.asarray(strata), np.asarray(labels)
    if strata.ndim == 1:
        strata = strata[:, None]
    if (labels.ndim != 1 or not len(labels) or not np.issubdtype(labels.dtype, np.integer)
            or not np.isin(labels, [0, 1, 2]).all() or strata.ndim != 2
            or len(strata) != len(labels) or not np.isfinite(change)):
        raise ValueError("Invalid reciprocal category, stratum or change inputs")
    return strata, labels, float(change)


def probabilities_with_middle_fixed(strata, labels, change):
    strata, labels, change = _inputs(strata, labels, change)
    n = len(labels)
    natural = np.bincount(labels, minlength=3) / n
    requested = float(natural[2] + change)
    active = labels != 1
    active_share = float(active.mean())
    p = np.full(n, 1 / n)
    if active_share:
        _, feasible = stratified_probabilities(strata[active], labels[active] == 2,
                                               natural[2] / active_share)
        minimum, maximum = active_share * feasible["minimum"], active_share * feasible["maximum"]
    else:
        minimum = maximum = 0.
    if not minimum - 1e-12 <= requested <= maximum + 1e-12:
        raise ValueError(f"Reciprocal change outside feasible [{minimum - natural[2]}, {maximum - natural[2]}]")
    if active_share:
        conditional, _ = stratified_probabilities(strata[active], labels[active] == 2,
                                                   requested / active_share)
        p[active] = active_share * conditional
    attained = np.bincount(labels, weights=p, minlength=3)
    report = dict(minimum=float(minimum), maximum=float(maximum),
                  minimum_change=float(minimum - natural[2]), maximum_change=float(maximum - natural[2]),
                  natural_fraction=float(natural[2]), requested_fraction=requested,
                  requested_change=change, attained_fraction=float(attained[2]),
                  attained_change=float(attained[2] - natural[2]),
                  natural_category_fractions=natural.tolist(), attained_category_fractions=attained.tolist(),
                  middle_episode_mass_fixed=True, effective_episodes=float(1 / np.square(p).sum()),
                  symmetry_claim="An exchange alone is not a mirrored pair")
    return p, report


def fixed_indices_with_middle_fixed(strata, labels, change, seed):
    strata, labels, change = _inputs(strata, labels, change)
    _, weighted = probabilities_with_middle_fixed(strata, labels, change)
    n = len(labels)
    target_count = round(n * weighted["requested_fraction"])
    active_ids = np.flatnonzero(labels != 1)
    middle_ids = np.flatnonzero(labels == 1)
    if target_count == int((labels == 2).sum()):
        indices = np.arange(n)
    else:
        active_indices, _ = fixed_stratified_indices(strata[active_ids], labels[active_ids] == 2,
                                                    target_count / len(active_ids), seed)
        indices = np.random.default_rng(seed).permutation(np.concatenate((middle_ids, active_ids[active_indices])))
    attained = np.bincount(labels[indices], minlength=3) / n
    report = dict(weighted)
    report.update(attained_fraction=float(attained[2]), attained_change=float(attained[2] - weighted["natural_fraction"]),
                  attained_category_fractions=attained.tolist(), total_episodes=n,
                  unique_episodes=len(np.unique(indices)), category_counts=np.bincount(labels[indices], minlength=3).tolist(),
                  integer_rounding_error=float(attained[2] - weighted["requested_fraction"]))
    return indices.astype(np.int64), report


def mirrored_pair(strata, labels, magnitude, seed):
    strata, labels, magnitude = _inputs(strata, labels, magnitude)
    if magnitude < 0:
        raise ValueError("Mirror magnitude must be nonnegative")
    n = len(labels)
    active_count = int((labels != 1).sum())
    center = active_count / (2 * n)
    natural_high = float((labels == 2).mean())
    high_count = round(active_count / 2 + n * magnitude)
    counts = {"low_heavy": active_count - high_count, "high_heavy": high_count}
    pair = {}
    for side, sign in (("low_heavy", -1), ("high_heavy", 1)):
        change = center + sign * magnitude - natural_high
        p, weighted = probabilities_with_middle_fixed(strata, labels, change)
        indices, fixed = fixed_indices_with_middle_fixed(strata, labels, counts[side] / n - natural_high, seed)
        weighted.update(requested_pair_magnitude=magnitude,
                        attained_pair_magnitude=float(abs(weighted["attained_fraction"] - center)),
                        symmetry_claim="Mirrored marginal category fractions, not a physical or conditional-stratum reflection")
        fixed.update(requested_change=change, requested_fraction=weighted["requested_fraction"],
                     requested_pair_magnitude=magnitude,
                     attained_pair_magnitude=float(abs(fixed["attained_fraction"] - center)),
                     integer_rounding_error=float(fixed["attained_fraction"] - weighted["requested_fraction"]),
                     symmetry_claim=weighted["symmetry_claim"])
        pair[side] = dict(probabilities=p, indices=indices, weighted=weighted, fixed=fixed)
    if (not np.allclose(pair["low_heavy"]["weighted"]["attained_category_fractions"],
                        pair["high_heavy"]["weighted"]["attained_category_fractions"][::-1], rtol=0, atol=1e-12)
            or pair["low_heavy"]["fixed"]["category_counts"] != pair["high_heavy"]["fixed"]["category_counts"][::-1]):
        raise ValueError("Achieved mirrored composition failed verification")
    return pair
