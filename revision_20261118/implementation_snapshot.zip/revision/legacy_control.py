"""Opt-in offline controls; unconfigured historical learners retain their defaults."""

from dataclasses import dataclass

import numpy as np

from revision.modern_data import ReferenceNormalizer


@dataclass
class FrozenLegacyNormalizer:
    mean: np.ndarray
    std: np.ndarray
    default_clip_range: float

    def normalize(self, values, clip_range=None):
        clip = self.default_clip_range if clip_range is None else clip_range
        return np.clip((values - self.mean) / self.std, -clip, clip)

    def update(self, values):
        raise RuntimeError("Attempt to mutate frozen offline normalization")

    def recompute_stats(self):
        raise RuntimeError("Attempt to recompute frozen offline normalization")


def install_legacy_control(agent, data, probabilities):
    if len(data["o"]) != agent.buffer.current_size:
        raise ValueError("Control data do not match the actually loaded buffer")
    probabilities = np.asarray(probabilities, dtype=np.float64)
    reference = ReferenceNormalizer.fit(data, probabilities)
    active = np.flatnonzero(probabilities > 0)
    for ids in np.array_split(active, max(1, len(active) // 128)):
        if any(np.max(np.abs(data[key][ids])) > agent.args.clip_obs for key in ("o", "ag", "g")):
            raise ValueError("Reference moments require an explicit preclip adapter for these data")
    agent.o_norm = FrozenLegacyNormalizer(reference.obs_mean, reference.obs_std, reference.clip)
    agent.g_norm = FrozenLegacyNormalizer(reference.goal_mean, reference.goal_std, reference.clip)
    agent.normalization_frozen = True
    agent.her_module.episode_probabilities = probabilities / probabilities.sum()
    agent.her_module.episode_draw_counts = np.zeros(len(probabilities), dtype=np.int64)
    agent.her_module.exposure_by_path = {}
    agent.her_module.sampling_path = "unclassified"
    return reference
