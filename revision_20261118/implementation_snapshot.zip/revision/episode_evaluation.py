"""Native episode outcomes with actual reset-state verification and bank roles."""

import json
from pathlib import Path

import numpy as np


def evaluate_policy(policy, env, count, step, output, bank=None, role="validation", step_key="updates"):
    if role not in ("validation", "final_test", "implementation_test") or count < 1:
        raise ValueError("Invalid evaluation role or count")
    if (role != "validation" and bank is None) or (bank is not None and len(bank.seeds) != count):
        raise ValueError("Missing or wrongly sized frozen evaluation bank")
    rows = []
    for index in range(count):
        seed = int(bank.seeds[index]) if bank is not None else 900000 + index
        observation, _ = env.reset(seed=seed)
        if bank is not None:
            bank.verify_reset(index, observation)
        initial = {key: np.asarray(value).tolist() for key, value in observation.items()}
        previous_goal = observation["desired_goal"].copy()
        successes, rewards, goal_changes = [], [], 0
        for _ in range(env.spec.max_episode_steps):
            action = np.asarray(policy(observation))
            if action.shape != env.action_space.shape or not np.isfinite(action).all():
                raise FloatingPointError("Invalid deterministic evaluation action")
            if np.any(action < env.action_space.low - 1e-6) or np.any(action > env.action_space.high + 1e-6):
                raise ValueError("Evaluation action outside native bounds")
            observation, reward, terminated, truncated, info = env.step(action)
            key = next((key for key in ("is_success", "success", "score/success") if key in info), None)
            if key is None or float(info[key]) not in (0., 1.) or not np.isfinite(reward):
                raise ValueError("Invalid native success or reward")
            successes.append(float(info[key]))
            rewards.append(float(reward))
            goal_changes += int(not np.array_equal(previous_goal, observation["desired_goal"]))
            previous_goal = observation["desired_goal"].copy()
            if terminated or truncated:
                break
        rows.append({step_key: step, "reset_seed": seed, "initial": initial,
                     "evaluation_role": role, "evaluation_bank_sha256": bank.sha256 if bank else None,
                     "final_success": successes[-1], "ever_success": max(successes),
                     "native_return": sum(rewards), "native_rewards": rewards, "steps": len(rewards),
                     "evaluation_discount": .99,
                     "discounted_native_return": float(np.dot(rewards, .99 ** np.arange(len(rewards)))),
                     "goal_changes": goal_changes, "terminated": bool(terminated), "truncated": bool(truncated),
                     "final_distance": float(np.linalg.norm(observation["achieved_goal"] - observation["desired_goal"]))})
        if role == "validation":
            rows[-1]["validation_reset_seed"] = seed
    with Path(output).open("a") as stream:
        for row in rows:
            stream.write(json.dumps(row, allow_nan=False) + "\n")
    return {key: float(np.mean([row[key] for row in rows])) for key in
            ("final_success", "ever_success", "native_return", "final_distance", "goal_changes")}
