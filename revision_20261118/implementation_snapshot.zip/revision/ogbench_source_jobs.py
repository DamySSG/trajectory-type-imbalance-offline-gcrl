"""Source prerequisites for the full OGBench extension, under shared limits."""


def source_jobs():
    jobs = []
    for task, seed in (('AntMazeLarge', 7011), ('CubeDouble', 7029)):
        for method in ('collector_random', 'collector_ddpg'):
            trained = method == 'collector_ddpg'
            smoke = f'source-smoke-v42-{task}-{method}'
            common = dict(task=task, method=method, seed=seed, action_seed=seed + 10000,
                          confirmatory=False, resume_allowed=False)
            jobs.append(dict(**common, id=smoke, stage='source_smoke', episodes=3,
                epochs=2 if trained else 1, n_cycles=1, n_batches=2 if trained else 1,
                updates=4 if trained else 0, eval_interval=1, eval_rollouts=2, depends_on=[]))
            jobs.append(dict(**common, id=f'source-full-v42-{task}-{method}',
                stage='source_collection', episodes=10000,
                epochs=1000 if trained else 1, n_cycles=50 if trained else 1,
                n_batches=40 if trained else 1, updates=2000000 if trained else 0,
                eval_interval=200, eval_rollouts=32, depends_on=[smoke]))
    return jobs


def choose_source_slot(method, running, free_mib, free_bytes):
    if free_bytes < 100 * 1024**3 or len(running) >= 30:
        return None
    cores = {row['physical_core'] for row in running}
    core = next((value for value in range(18, 48) if value not in cores), None)
    if core is None:
        return None
    if method == 'collector_random':
        return core, None
    if method != 'collector_ddpg':
        raise ValueError('Undeclared source method')
    reserved = {}
    for row in running:
        if row.get('gpu') is not None:
            gpu = row['gpu']
            reserved[gpu] = reserved.get(gpu, 0) + row.get('gpu_reservation_mib', 3072)
    available = {gpu: amount - reserved.get(gpu, 0) for gpu, amount in free_mib.items()}
    gpu = max(available, key=available.get) if available else None
    return (core, gpu) if gpu is not None and available[gpu] >= 3072 + 4096 else None
