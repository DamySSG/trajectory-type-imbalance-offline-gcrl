"""Baseline validation with exact data identities and episode-level evaluation."""

import argparse
import hashlib
import importlib.metadata
import json
import os
import pickle
import random
import subprocess
import time
from pathlib import Path

import gymnasium as gym
import gymnasium_robotics  # noqa: F401: registers the historical task versions
import numpy as np
import torch

from revision.audit_sources import sha256
from revision.control_dataset import selection_for_config, control_exposure_summary
from revision.episode_evaluation import evaluate_policy
from revision.frozen_experiment import validate_frozen_job, save_at_checkpoint
from revision.legacy_control import install_legacy_control
from revision.protocol import mixture_indices
from revision.task_catalog import task_spec, source_catalog, validate_task_buffer
from revision.queue import stamp, write_json
from rl_modules.ddpg_agent import DDPG
from rl_modules.gcsl_agent import GCSL
from rl_modules.gofar_agent import GoFAR


def rng_state():
    return {"python": random.getstate(), "numpy": np.random.get_state(),
            "torch": torch.get_rng_state(), "cuda": torch.cuda.get_rng_state_all()}


def restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    torch.cuda.set_rng_state_all(state["cuda"])


def checkpoint(agent, path, epoch, config_hash, data_hash):
    objects = {name: value.state_dict() for name, value in vars(agent).items()
               if isinstance(value, (torch.nn.Module, torch.optim.Optimizer))}
    if hasattr(agent, "discriminator"):
        objects["discriminator_optimizer"] = agent.discriminator.optimizer.state_dict()
    norms = {name: {k: v for k, v in vars(getattr(agent, name)).items() if k != "lock"}
             for name in ("o_norm", "g_norm")}
    state = {"epoch": epoch, "objects": objects, "normalizers": norms,
             "rng": rng_state(), "config_hash": config_hash, "data_hash": data_hash,
             "her_sampling": dict(episode_probabilities=agent.her_module.episode_probabilities,
                                  episode_draw_counts=agent.her_module.episode_draw_counts,
                                  exposure_by_path=agent.her_module.exposure_by_path),
             "normalization_frozen": getattr(agent, "normalization_frozen", False)}
    temporary = path.with_suffix(".tmp")
    torch.save(state, temporary)
    os.replace(temporary, path)


def evaluate(agent, env, count, epoch, output, bank=None, role="validation"):
    saved_rng = rng_state()
    def policy(observation):
        with torch.no_grad():
            tensor = agent._preproc_inputs(observation["observation"], observation["desired_goal"])
            return agent._deterministic_action(tensor).detach().cpu().numpy().reshape(-1)
    try:
        return evaluate_policy(policy, env, count, epoch, output, bank=bank, role=role, step_key="epoch")
    finally:
        restore_rng(saved_rng)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    opts = parser.parse_args()
    cfg = json.loads(opts.config.read_text())
    run_dir = opts.config.parent
    if any((run_dir / name).exists() for name in ("runtime.json", "result.json", "validation_episodes.jsonl", "test_episodes.jsonl")):
        raise ValueError("Attempt already contains evidence; use a separate new attempt")
    frozen = validate_frozen_job(cfg) if cfg["stage"] in ("confirmatory", "frozen_runner_validation") else None
    if cfg["stage"] not in ("smoke", "calibration", "control_validation") and frozen is None:
        raise ValueError("Confirmatory jobs require a separately frozen protocol")
    config_hash = sha256(opts.config)
    started = time.monotonic()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    random.seed(cfg["seed"])
    np.random.seed(cfg["seed"])
    torch.manual_seed(cfg["seed"])
    torch.cuda.manual_seed_all(cfg["seed"])
    torch.backends.cudnn.benchmark = False
    spec = task_spec(cfg["task"])
    env = gym.make(spec.native_id)
    if env.spec.max_episode_steps != spec.horizon:
        raise ValueError("Native task horizon changed")
    initial, _ = env.reset(seed=cfg["seed"])
    env.action_space.seed(cfg["seed"])
    pools, provenance = [], []
    for source in source_catalog(cfg):
        path = source["path"]
        with path.open("rb") as stream:
            data = pickle.load(stream)
        schema = validate_task_buffer(data, cfg["task"])
        pools.append(data)
        provenance.append({**{key: value for key, value in source.items() if key != "path"}, "path": str(path), **schema})
    selection = mixture_indices(len(pools[0]["o"]), len(pools[1]["o"]), cfg["episodes"], cfg.get("source_zero_fraction", .5), cfg["data_seed"])
    selection, control = selection_for_config(cfg, selection)
    if any(np.any(selection[selection[:, 0] == source, 1] >= len(pools[source]["o"])) for source in (0, 1)):
        raise ValueError("Control indexes lie outside the original source pools")
    buffers = {}
    for raw, key in {"o": "obs", "ag": "ag", "g": "g", "u": "actions"}.items():
        if pools[0][raw].shape[1:] != pools[1][raw].shape[1:]:
            raise ValueError("Expert and random source schemas disagree")
        output = np.empty((len(selection), *pools[0][raw].shape[1:]), dtype=np.float64)
        for source in (0, 1):
            mask = selection[:, 0] == source
            output[mask] = pools[source][raw][selection[mask, 1]]
        buffers[key] = output
    del pools
    np.savez_compressed(run_dir / "episode_ids.npz", source=selection[:, 0], episode=selection[:, 1])
    data_hash = hashlib.sha256(selection.tobytes() + "".join(p["sha256"] for p in provenance).encode()).hexdigest()
    if control is not None:
        data_hash = hashlib.sha256((data_hash + json.dumps(control.metadata, sort_keys=True)).encode()).hexdigest()
        np.savez_compressed(run_dir / "control_view.npz", episode_probabilities=control.probabilities,
                            slot_indices=control.slot_indices if control.slot_indices is not None else np.array([], dtype=int))
    write_json(run_dir / "data_manifest.json", {"sources": provenance, "selection_sha256": data_hash,
               "loaded_episodes": len(selection), "unique_ids": len(np.unique(selection, axis=0)),
               "source_counts": {spec.source_zero_name: int(np.sum(selection[:, 0] == 0)), "random": int(np.sum(selection[:, 0] == 1))},
               "transitions": len(selection) * buffers["actions"].shape[1], "data_seed": cfg["data_seed"],
               "control": control.metadata if control is not None else None})
    print(f"{stamp()} loaded exact {len(selection)} episodes; source counts={np.bincount(selection[:, 0], minlength=2).tolist()}; data={data_hash}", flush=True)
    params = {"obs": len(initial["observation"]), "goal": len(initial["desired_goal"]),
              "action": env.action_space.shape[0], "action_max": env.action_space.high[0],
              "action_space": env.action_space, "max_timesteps": spec.horizon + spec.stored_observation_offset}
    if buffers["obs"].shape[-1] != params["obs"] or buffers["actions"].shape[-1] != params["action"]:
        raise ValueError("Dataset/environment feature mapping mismatch")
    # Allocate one dummy episode in the legacy constructor, then replace it with
    # the exactly selected arrays. This cannot silently truncate the offline data.
    args = argparse.Namespace(env=cfg["task"], run_name=cfg["id"], save_dir=str(run_dir / "models"),
        buffer_size=params["max_timesteps"], batch_size=cfg["batch_size"], clip_range=5,
        clip_obs=200, replay_strategy="future", relabel_percent={"ddpg": .5, "gcsl": 1., "wgcsl": 1., "gofar": 0.}[cfg["method"]],
        threshold=spec.success_threshold, cuda=True, method=cfg["method"],
        lr_actor=5e-4 if "gcsl" in cfg["method"] else 1e-3,
        lr_critic=5e-4 if "gcsl" in cfg["method"] else 1e-3,
        polyak=.95, gamma=.98, action_l2=1., f="chi", disc_lambda=.01, disc_iter=20,
        reward_type="disc" if cfg["method"] == "gofar" else "binary")
    agent = {"ddpg": DDPG, "gcsl": GCSL, "wgcsl": GCSL, "gofar": GoFAR}[cfg["method"]](args, env, params)
    agent.buffer.buffers = buffers
    agent.buffer.size = agent.buffer.current_size = len(selection)
    agent.buffer.n_transitions_stored = len(selection) * buffers["actions"].shape[1]
    native_reward = env.unwrapped.compute_reward
    agent.her_module.reward_func = (lambda a, g, info: native_reward(a, g, info) - 1.) if spec.family == "maze" else native_reward
    reference = None
    if control is not None or cfg.get("normalization") == "reference_support":
        data = {raw: buffers[key] for raw, key in {"o": "obs", "ag": "ag", "g": "g", "u": "actions"}.items()}
        probabilities = control.probabilities if control is not None else np.ones(len(selection)) / len(selection)
        reference = install_legacy_control(agent, data, probabilities)
    packages = {}
    for package in ("torch", "numpy", "gymnasium", "gymnasium-robotics", "mujoco", "mujoco-py", "mpi4py-mpich"):
        packages[package] = importlib.metadata.version(package)
    code_root = Path(__file__).resolve().parent.parent
    hashes = {str(p.relative_to(code_root)): sha256(p) for folder in ("revision", "rl_modules", "her_modules", "mpi_utils")
              for p in sorted((code_root / folder).glob("*.py"))}
    frozen_metadata = {key: value for key, value in frozen.items() if key != "bank"} if frozen else None
    write_json(run_dir / "runtime.json", {"packages": packages, "code_hashes": hashes,
        "config_sha256": config_hash, "env_spec": str(env.spec), "args": vars(args),
        "cpu_affinity": sorted(os.sched_getaffinity(0)), "pid": os.getpid(),
        "torch_device": torch.cuda.get_device_name(), "validation_bank_start": 900000,
        "training_reward": "PointMaze native sparse reward minus 1; Fetch native sparse reward",
        "normalization": reference.as_dict() if reference is not None else "native per-sampled-batch updates (calibration only)",
        "control": control.metadata if control is not None else None,
        "frozen_protocol": frozen_metadata, "final_bank_sha256": frozen["bank"].sha256 if frozen else None,
        "checkpoint_policy": cfg.get("checkpoint_policy", "all_evaluated"),
        "not_confirmatory": not bool(frozen and frozen["confirmatory"]),
        "hardware": subprocess.check_output(["nvidia-smi", "--query-gpu=uuid,name,driver_version", "--format=csv,noheader"], text=True)})
    metrics = []
    for epoch in range(cfg["epochs"] + 1):
        if epoch > 0:
            for _ in range(cfg["n_cycles"]):
                if cfg["method"] == "gofar":
                    for _ in range(args.disc_iter):
                        agent._update_discriminator(future_p=agent.her_module.future_p)
                for _ in range(cfg["n_batches"]):
                    agent._update_network(future_p=agent.her_module.future_p)
                agent._soft_update()
            for name, module in vars(agent).items():
                if isinstance(module, torch.nn.Module) and any(not torch.isfinite(p).all() for p in module.parameters()):
                    raise FloatingPointError(f"Non-finite model parameters: {name}")
        if epoch % cfg["eval_interval"] == 0 or epoch == cfg["epochs"]:
            result = evaluate(agent, env, cfg["eval_rollouts"], epoch, run_dir / "validation_episodes.jsonl")
            metrics.append({"epoch": epoch, "updates": epoch * cfg["n_cycles"] * cfg["n_batches"], **result})
            if save_at_checkpoint(cfg, epoch, cfg["epochs"]):
                checkpoint(agent, run_dir / f"checkpoint_epoch{epoch:04d}.pt", epoch, config_hash, data_hash)
            print(f"{stamp()} {cfg['id']} epoch={epoch} validation={result}", flush=True)
        write_json(run_dir / "progress.json", {"status": "running", "epoch": epoch,
            "total_epochs": cfg["epochs"], "last_update": stamp(), "elapsed_seconds": time.monotonic() - started,
            "cuda_peak_allocated_bytes": torch.cuda.max_memory_allocated(), "validation": metrics})
    final_evaluation = None
    if frozen is not None:
        final_evaluation = evaluate(agent, env, len(frozen["bank"].seeds), cfg["epochs"],
            run_dir / "test_episodes.jsonl", bank=frozen["bank"],
            role="final_test" if frozen["confirmatory"] else "implementation_test")
    env.close()
    exposure = None
    if control is not None:
        np.savez_compressed(run_dir / "sampling_exposure.npz", **agent.her_module.exposure_by_path)
        exposure = control_exposure_summary(control, agent.her_module.exposure_by_path)
    write_json(run_dir / "result.json", {"status": "complete", "stage": cfg["stage"],
        "id": cfg["id"], "seed": cfg["seed"], "data_seed": cfg["data_seed"],
        "updates": cfg["epochs"] * cfg["n_cycles"] * cfg["n_batches"], "metrics": metrics,
        "elapsed_seconds": time.monotonic() - started, "config_sha256": config_hash,
        "data_sha256": data_hash, "cuda_peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "control": control.metadata if control is not None else None, "control_exposure": exposure,
        "final_evaluation": final_evaluation, "frozen_protocol": frozen_metadata,
        "test_episodes_sha256": sha256(run_dir / "test_episodes.jsonl") if frozen else None,
        "final_bank_sha256": frozen["bank"].sha256 if frozen else None,
        "checkpoint_sha256": sha256(run_dir / f"checkpoint_epoch{cfg['epochs']:04d}.pt"),
        "not_confirmatory": not bool(frozen and frozen["confirmatory"])})


if __name__ == "__main__":
    main()
