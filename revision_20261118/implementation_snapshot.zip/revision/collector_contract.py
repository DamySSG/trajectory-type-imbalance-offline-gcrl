"""Complete native-horizon collection for new sources, distinct from old H-1 buffers."""

import numpy as np


def seed_bank(purpose, count):
    starts = {"online_training": 2100000, "trained_collection": 4100000,
              "random_collection": 6100000, "final_test": 1900000, "validation": 900000}
    if purpose not in starts or not isinstance(count, int) or not 0 < count <= 100000:
        raise ValueError("Invalid seed-bank purpose or count")
    return np.arange(starts[purpose], starts[purpose] + count, dtype=np.int64)


def complete_rollout(env, policy, reset_seed):
    observation, _ = env.reset(seed=int(reset_seed))
    initial = {key: np.asarray(value).tolist() for key, value in observation.items()}
    desired = observation["desired_goal"].copy()
    states, achieved = [observation["observation"].copy()], [observation["achieved_goal"].copy()]
    goals, actions, rewards, successes = [], [], [], []
    horizon = env.spec.max_episode_steps
    for step in range(horizon):
        if not all(np.isfinite(value).all() for value in observation.values()):
            raise ValueError("Non-finite collector observation")
        action = np.asarray(policy(observation), dtype=np.float64)
        if (action.shape != env.action_space.shape or not np.isfinite(action).all() or
                np.any(action < env.action_space.low) or np.any(action > env.action_space.high)):
            raise ValueError("Invalid collector action; do not silently repair the record")
        goals.append(observation["desired_goal"].copy())
        actions.append(action.copy())
        observation, reward, terminated, truncated, info = env.step(action)
        if not np.array_equal(desired, observation["desired_goal"]):
            raise ValueError("Goal changed in a fixed-goal source rollout")
        if not all(np.isfinite(value).all() for value in observation.values()) or not np.isfinite(reward):
            raise ValueError("Non-finite collector next state or reward")
        key = next((key for key in ("is_success", "success", "score/success") if key in info), None)
        if key is None or float(info[key]) not in (0., 1.):
            raise ValueError("Missing binary native success event")
        states.append(observation["observation"].copy())
        achieved.append(observation["achieved_goal"].copy())
        rewards.append(float(reward))
        successes.append(float(info[key]))
        if (terminated or truncated) and step + 1 != horizon:
            raise ValueError("Unexpected early termination; do not pad a fixed-length source")
    data = {"o": np.asarray(states), "ag": np.asarray(achieved),
            "g": np.asarray(goals), "u": np.asarray(actions)}
    record = dict(reset_seed=int(reset_seed), initial=initial, steps=horizon,
                  native_rewards=rewards, final_success=successes[-1], ever_success=max(successes),
                  native_return=sum(rewards), terminated=bool(terminated), truncated=bool(truncated),
                  goal_changes=0, final_distance=float(np.linalg.norm(achieved[-1] - desired)))
    return data, record


def collector_forecast(horizon, observations, achieved, actions, episodes, epochs, cycles, batches):
    if any(not isinstance(value, int) or value <= 0 for value in
           (horizon, observations, achieved, actions, episodes, epochs, cycles, batches)):
        raise ValueError("Positive integer dimensions and budgets required")
    return dict(offline_transitions=2 * episodes * horizon,
                raw_float64_bytes=2 * episodes * ((horizon + 1) * (observations + achieved) +
                                                   horizon * (achieved + actions)) * 8,
                online_transitions=epochs * cycles * horizon,
                online_policy_updates=epochs * cycles * batches,
                source_policy_replications=1,
                scope="Two sources from one declared trained policy and one uniform-action policy; not learner-seed replication")
