"""Descriptive dependence and feasible stratum-preserving interventions."""

import numpy as np


def _weights(n, weights):
    values = np.ones(n) if weights is None else np.asarray(weights, dtype=np.float64)
    if values.shape != (n,) or not np.isfinite(values).all() or (values < 0).any() or values.sum() <= 0:
        raise ValueError("Invalid audit weights")
    return values


def contingency(a, b, weights=None):
    a, b = np.asarray(a), np.asarray(b)
    if a.shape != b.shape or a.ndim != 1:
        raise ValueError("Invalid category arrays")
    weights = _weights(len(a), weights)
    rows, ai = np.unique(a, return_inverse=True)
    columns, bi = np.unique(b, return_inverse=True)
    values = np.zeros((len(rows), len(columns)))
    np.add.at(values, (ai, bi), weights)
    return dict(rows=rows.tolist(), columns=columns.tolist(), values=values.tolist())


def cramers_v(a, b, weights=None):
    table = np.asarray(contingency(a, b, weights)["values"])
    table = table[table.sum(axis=1) > 0][:, table.sum(axis=0) > 0]
    if min(table.shape) <= 1:
        return None
    total = table.sum()
    expected = np.outer(table.sum(axis=1), table.sum(axis=0)) / total
    chi = np.square(table - expected) / expected
    return float(np.sqrt(chi.sum() / total / (min(table.shape) - 1)))


def numeric_summary(values, weights=None):
    values = np.asarray(values, dtype=np.float64)
    weights = _weights(len(values), weights)
    if values.ndim != 1 or not np.isfinite(values).all():
        raise ValueError("Invalid numeric audit values")
    active = weights > 0
    values, weights = values[active], weights[active]
    weights = weights / weights.sum()
    mean = float(weights @ values)
    order = np.argsort(values, kind="stable")
    cdf = np.cumsum(weights[order])
    indices = np.minimum(np.searchsorted(cdf, [.1, .25, .5, .75, .9]), len(values) - 1)
    return dict(mean=mean, std=float(np.sqrt(weights @ np.square(values - mean))),
                min=float(values.min()), max=float(values.max()),
                inverse_cdf_quantiles=values[order][indices].tolist(),
                active_episodes=len(values), effective_episodes=float(1 / np.square(weights).sum()))


def stratified_probabilities(strata, target, target_fraction):
    strata, target = np.asarray(strata), np.asarray(target, dtype=bool)
    if strata.ndim == 1:
        strata = strata[:, None]
    if strata.ndim != 2 or len(strata) != len(target) or target.ndim != 1 or not len(target):
        raise ValueError("Invalid joint strata and target arrays")
    _, group = np.unique(strata, axis=0, return_inverse=True)
    count = np.bincount(group).astype(float)
    selected = np.bincount(group, weights=target, minlength=len(count))
    prevalence, share = selected / count, count / count.sum()
    minimum, maximum = float(share[prevalence == 1].sum()), float(share[prevalence > 0].sum())
    if not minimum - 1e-12 <= target_fraction <= maximum + 1e-12:
        raise ValueError(f"Requested fraction outside feasible [{minimum}, {maximum}]")
    if np.isclose(target_fraction, minimum, atol=1e-12, rtol=0):
        conditional = (prevalence == 1).astype(float)
    elif np.isclose(target_fraction, maximum, atol=1e-12, rtol=0):
        conditional = (prevalence > 0).astype(float)
    else:
        interior = (prevalence > 0) & (prevalence < 1)
        odds = np.log(prevalence[interior]) - np.log1p(-prevalence[interior])
        conditional = prevalence.copy()
        low, high = -700., 700.
        for _ in range(100):
            mid = (low + high) / 2
            conditional[interior] = 1 / (1 + np.exp(-np.clip(odds + mid, -700, 700)))
            if share @ conditional < target_fraction:
                low = mid
            else:
                high = mid
    probabilities = np.zeros(len(target))
    for label, cells, mass in ((True, selected, share * conditional),
                               (False, count - selected, share * (1 - conditional))):
        active = (target == label) & (cells[group] > 0)
        probabilities[active] = mass[group[active]] / cells[group[active]]
    probabilities /= probabilities.sum()
    return probabilities, dict(minimum=minimum, maximum=maximum, natural_fraction=float(target.mean()),
                               attained_fraction=float(probabilities[target].sum()),
                               joint_strata=len(count), effective_episodes=float(1 / np.square(probabilities).sum()))


def fixed_stratified_indices(strata, target, target_fraction, seed):
    """Keep every original joint-cell count; integer-round one global type count."""
    strata, target = np.asarray(strata), np.asarray(target, dtype=bool)
    if strata.ndim == 1:
        strata = strata[:, None]
    total = len(target)
    n_target = round(total * target_fraction)
    probabilities, feasibility = stratified_probabilities(strata, target, n_target / total)
    cells, group = np.unique(strata, axis=0, return_inverse=True)
    counts = np.bincount(group)
    selected = np.bincount(group, weights=target, minlength=len(cells)).astype(int)
    expected = np.bincount(group[target], weights=total * probabilities[target], minlength=len(cells))
    minimum = np.where(selected == counts, counts, 0)
    maximum = np.where(selected > 0, counts, 0)
    allocation = np.clip(np.floor(expected + 1e-10).astype(int), minimum, maximum)
    remaining = n_target - allocation.sum()
    while remaining:
        candidates = np.flatnonzero(allocation < maximum if remaining > 0 else allocation > minimum)
        if not len(candidates):
            raise ValueError("Integer matched-cell quotas are not feasible")
        residual = expected[candidates] - allocation[candidates]
        chosen = candidates[np.argmax(residual) if remaining > 0 else np.argmin(residual)]
        direction = 1 if remaining > 0 else -1
        allocation[chosen] += direction
        remaining -= direction
    if np.isclose(n_target / total, target.mean(), atol=1e-12, rtol=0):
        indices = np.arange(total)
    else:
        rng = np.random.default_rng(seed)
        parts = []
        for cell in range(len(cells)):
            for label, count in ((True, allocation[cell]), (False, counts[cell] - allocation[cell])):
                ids = np.flatnonzero((group == cell) & (target == label))
                if count and not len(ids):
                    raise ValueError("Requested matched cell is empty")
                copies, remainder = divmod(count, len(ids)) if len(ids) else (0, 0)
                parts.extend([np.tile(ids, copies), rng.choice(ids, remainder, replace=False)])
        indices = rng.permutation(np.concatenate(parts).astype(np.int64))
    report = dict(**feasibility, requested_fraction=target_fraction,
                  total_episodes=total, unique_episodes=len(np.unique(indices)),
                  exact_joint_cell_counts=counts.tolist(), cells=cells.tolist(),
                  target_cell_counts=allocation.tolist(),
                  weighted_expected_target_cell_counts=expected.tolist(),
                  integer_rounding_max_cell_error=float(np.max(np.abs(allocation - expected))))
    report["weighted_expected_fraction"] = feasibility["attained_fraction"]
    report["attained_fraction"] = int(target[indices].sum()) / total
    return indices, report
