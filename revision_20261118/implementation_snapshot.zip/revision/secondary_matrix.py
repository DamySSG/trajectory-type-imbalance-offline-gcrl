"""Bounded original-task secondary packages, with explicit paired linear contrasts."""

import argparse
import json
from pathlib import Path, PurePosixPath

import numpy as np

from revision.control_dataset import load_control_selection
from revision.primary_matrix import primary_matrix, comparison_families, AXES, SEEDS
from revision.queue import stamp, write_json
from revision.secondary_controls import VARIANT_AXES


def secondary_matrix(root, resolve, sensitivity_amplitude=.025, tag="v18"):
    if sensitivity_amplitude not in (.05, .025, .01):
        raise ValueError("Sensitivity dose requires a prespecified support-feasibility choice")
    primary = primary_matrix(root, tag)
    natural = {(job["task"], job["method"], job["seed"]): job for job in primary
               if job["variant"]["kind"] == "natural"}
    primary_ids = {(job["task"], job["method"], job["seed"], job["variant"]["axis"],
                   job["variant"]["level"], job["variant"]["change"], job["variant"]["arm"]): job["id"]
                   for job in primary if job["variant"]["kind"] == "intervention"}
    jobs, groups, small_ids = [], {}, {}
    representative = ("gofar", "hiql", "crl", "smore")
    limited = ("gofar", "smore")

    def create(package, task, method, seed, suffix, folder, labels, selector, arm="weighted", fraction=.5, **variant):
        base = natural[task, method, seed]
        identity = f"secondary-{tag}-{task}-{method}-{package}-{suffix}-s{seed}"
        control = resolve(folder, labels, task, seed+1000, arm, selector)
        job = dict(**{key: value for key, value in base.items() if key not in ("id", "control", "variant", "depends_on", "purpose")},
            id=identity, control=control, depends_on=[base["id"]], source_zero_fraction=fraction,
            purpose="confirmatory_prespecified_secondary_composition_analysis",
            variant=dict(kind="secondary", package=package, **variant))
        jobs.append(job)
        return identity

    def contrast(package, task, key, seed, terms, **details):
        family = groups.setdefault((package, task), {})
        row = family.setdefault(key, dict(id=key, pairs=[], **details))
        row["pairs"].append(dict(seed=seed, terms=[dict(run=run, coefficient=coefficient) for run, coefficient in terms]))

    for task in ("FetchPush", "PointMaze"):
        labels = root / f"audit/measurements_v1/labels_{task}.npz"
        for method in limited:
            for seed in SEEDS:
                for package, magnitude in (("original_small", sensitivity_amplitude), ("mixture50_reference", .05)):
                    for axis in AXES:
                        for change in (-magnitude, magnitude):
                            cohort = root / f"audit/secondary_controls_v3/sensitivity/primary/{task}_d{seed+1000}"
                            selector = dict(axis=axis, level=2, control="quality_cross_axis", requested_change=change)
                            identity = create(package, task, method, seed, f"{axis}-d{change:+.3f}", cohort, labels,
                                              selector, axis=axis, change=change)
                            small_ids[package, task, method, seed, axis, change] = identity
                            contrast(package, task, f"{package}-{method}-{axis}-{change:+.3f}", seed,
                                     [(identity, 1), (natural[task, method, seed]["id"], -1)], method=method, axis=axis, change=change)
        for method in representative:
            for seed in SEEDS:
                cohort = root / f"audit/mixture_and_dose_controls_v1/mixture_50/{task}_d{seed+1000}"
                for axis in AXES:
                    for change in (-.10, .10):
                        identity = create("source_only", task, method, seed, f"{axis}-d{change:+.2f}", cohort, labels,
                            dict(axis=axis, level=2, control="source_only", requested_change=change), axis=axis, change=change)
                        reference = primary_ids[task, method, seed, axis, 2, change, "weighted"]
                        contrast("source_only_minus_matched", task, f"source-{method}-{axis}-{change:+.2f}", seed,
                                 [(identity, 1), (reference, -1)], method=method, axis=axis, change=change)
                mirror = root / f"audit/reciprocal_controls_v2/{task}_d{seed+1000}"
                for arm in ("weighted", "fixed_size"):
                    sides = {}
                    for side in ("low_heavy", "high_heavy"):
                        manifest = f"action_direction_reciprocal_quality_cross_axis_mirror_m0.050_{side}.npz"
                        sides[side] = create("reciprocal", task, method, seed, f"action-{arm}-{side}", mirror, labels,
                            dict(axis="action_direction", level=2, control="quality_cross_axis", manifest=manifest),
                            arm=arm, axis="action_direction", side=side, magnitude_from_equal_extremes=.05)
                    contrast("reciprocal", task, f"reciprocal-{method}-{arm}", seed,
                        [(sides["high_heavy"], 1), (sides["low_heavy"], -1)], method=method, arm=arm,
                        interpretation="Marginal composition mirror only; no task-physics or conditional-distribution symmetry assumed")
        for method in limited:
            for seed in SEEDS:
                removal = root / f"audit/secondary_controls_v3/removal/{task}_d{seed+1000}"
                for axis in AXES:
                    for arm in ("weighted", "fixed_size"):
                        identity = create("removal", task, method, seed, f"{axis}-{arm}", removal, labels,
                            dict(axis=axis, level=2, control="source_only", requested_fraction=0.),
                            arm=arm, axis=axis, level=2, quality_held_fixed=False)
                        contrast("removal", task, f"removal-{method}-{axis}-{arm}", seed,
                                 [(identity, 1), (natural[task, method, seed]["id"], -1)], method=method, axis=axis, arm=arm)
                for fraction in (.25, .75):
                    cohort = root / f"audit/mixture_and_dose_controls_v1/mixture_{round(100*fraction)}/{task}_d{seed+1000}"
                    baseline = create("mixture", task, method, seed, f"m{fraction:.2f}-natural", cohort, labels,
                        dict(axis="goal_separation", level=0, control="quality_cross_axis", requested_change=0.),
                        fraction=fraction, source_zero_fraction=fraction, natural=True)
                    for axis in AXES:
                        for change in (-.05, .05):
                            identity = create("mixture", task, method, seed, f"m{fraction:.2f}-{axis}-d{change:+.2f}", cohort, labels,
                                dict(axis=axis, level=2, control="quality_cross_axis", requested_change=change),
                                fraction=fraction, axis=axis, change=change, source_zero_fraction=fraction)
                            jobs[-1]["depends_on"].append(baseline)
                            reference = small_ids["mixture50_reference", task, method, seed, axis, change]
                            contrast("mixture_interaction", task, f"mixture-{method}-m{fraction:.2f}-{axis}-{change:+.2f}", seed,
                                [(identity, 1), (baseline, -1), (reference, -1), (natural[task, method, seed]["id"], 1)],
                                method=method, axis=axis, fraction=fraction, change=change,
                                estimand="Difference of paired composition effects between this source mixture and50/50")
                for variant, axis in VARIANT_AXES.items():
                    folder = root / f"audit/secondary_controls_v3/sensitivity/{variant}"
                    variant_labels = folder / f"labels_{task}.npz"
                    for change in (-sensitivity_amplitude, sensitivity_amplitude):
                        identity = create("threshold", task, method, seed, f"{variant}-d{change:+.3f}",
                            folder / f"{task}_d{seed+1000}", variant_labels,
                            dict(axis=axis, level=2, control="quality_cross_axis", requested_change=change),
                            axis=axis, measurement_variant=variant, change=change)
                        reference = small_ids["original_small", task, method, seed, axis, change]
                        contrast("threshold", task, f"threshold-{method}-{variant}-{change:+.3f}", seed,
                            [(identity, 1), (reference, -1)], method=method, axis=axis, measurement_variant=variant, change=change,
                            estimand="Variant-defined versus original-defined composition at the same achieved dose")
    if len(jobs) != 720 or len({job["id"] for job in jobs}) != 720:
        raise ValueError("Secondary matrix count or identity drift")
    families = [dict(id=f"secondary_{package}_{task}", role="secondary", package=package, task=task,
        endpoint="final_success", contrasts=list(rows.values()), multiplicity="Holm within this prespecified package/task family",
        replication_unit="Three paired learner/data-seed blocks; no episode or condition inflation",
        exact_test_minimum_two_sided_p=.25, nonrejection_is_not_equivalence=True)
        for (package, task), rows in groups.items()]
    return jobs, families


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--local", type=Path, required=True)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--tag", default="v18")
    args = parser.parse_args()
    root = PurePosixPath(args.remote_root)
    summary = json.loads((args.local / "revision/audit/secondary_controls_v3/summary.json").read_text())
    magnitude = summary["common_sensitivity_amplitude"]

    def local(path):
        return args.local / "revision" / str(PurePosixPath(path).relative_to(root))

    def resolve(folder, labels, task, seed, arm, selector):
        audit = json.loads(local(folder / "audit.json").read_text())
        rows = [row for row in audit["candidate_controls"] if all(
            np.isclose(row.get(key, np.inf), value, rtol=0, atol=1e-12) if isinstance(value, float)
            else row.get(key) == value for key, value in selector.items())]
        if len(rows) != 1 or not rows[0]["feasible"]:
            raise ValueError(f"Missing unique feasible prespecified control:{folder}:{selector}")
        return dict(cohort=str(folder / "cohort.npz"), condition=str(folder / rows[0]["manifest"]),
                    labels=str(labels), arm=arm)

    primary = primary_matrix(root, args.tag)
    extra, families = secondary_matrix(root, resolve, magnitude, args.tag)
    jobs = primary + extra
    views = {}
    for job in jobs:
        control = job["control"]
        key = tuple(control[name] for name in ("cohort", "condition", "labels", "arm"))
        if key not in views:
            view = load_control_selection(*(local(control[name]) for name in ("cohort", "condition", "labels")),
                                           control["arm"], job["task"], job["data_seed"])
            views[key] = dict(control=control, metadata=view.metadata)
    args.output.mkdir(parents=True, exist_ok=False)
    write_json(args.output / "candidate_matrix.json", jobs)
    write_json(args.output / "candidate_comparisons.json", comparison_families(primary) + families)
    write_json(args.output / "loader_validation.json", dict(created=stamp(), jobs=len(jobs), unique_views=len(views),
        views=list(views.values()), policy_results_used=False, status="candidate_loader_views_verified_not_scientifically_frozen"))
    write_json(args.output / "candidate_status.json", dict(created=stamp(), jobs=len(jobs), primary=1050, secondary=720,
        sensitivity_amplitude=magnitude, status="candidate_not_frozen_not_queued", final_test_outcomes_used=False,
        additional_tasks=dict(status="separate_source_gated_package_not_in_this_matrix", planned_jobs=168,
            methods=["gofar", "hiql", "crl", "smore"], tasks=["FetchSlide", "PointMazeLarge"], source_fraction=.5,
            arm="weighted", balancing="source_only", upper_types=3, signs=[-1, 1],
            common_dose_candidates=[.05, .025, .01], selection="Largest feasible common upper-type dose across both signs, tasks and three seed cohorts; no policy outcomes",
            limitation="Different contact dynamics/maze layout/horizon, not higher observation dimensionality")))
    print(json.dumps(dict(jobs=len(jobs), unique_views=len(views), status="candidate_not_frozen_not_queued")))


if __name__ == "__main__":
    main()
