"""Goal-coordinate adapters with auditable episode-level intervention support."""

from dataclasses import dataclass

import numpy as np

from revision.protocol import validate_buffer


def _moments(arrays, active):
    count = 0
    total = square = None
    for array in arrays:
        for ids in np.array_split(active, max(1, len(active) // 128)):
            values = np.asarray(array[ids], dtype=np.float64).reshape(-1, array.shape[-1])
            if total is None:
                total = np.zeros(values.shape[-1])
                square = np.zeros_like(total)
            count += len(values)
            total += values.sum(axis=0)
            square += np.square(values).sum(axis=0)
    mean = total / count
    return mean, np.maximum(np.sqrt(np.maximum(square / count - mean**2, 0)), 1e-3)


@dataclass(frozen=True)
class ReferenceNormalizer:
    obs_mean: np.ndarray
    obs_std: np.ndarray
    goal_mean: np.ndarray
    goal_std: np.ndarray
    active_episodes: int
    clip: float = 5.

    @classmethod
    def fit(cls, data, probabilities, clip=5.):
        validate_buffer(data)
        probabilities = np.asarray(probabilities)
        if (probabilities.shape != (len(data["o"]),) or not np.isfinite(probabilities).all()
                or (probabilities < 0).any() or probabilities.sum() <= 0):
            raise ValueError("Invalid normalizer support probabilities")
        active = np.flatnonzero(probabilities > 0)
        om, os = _moments((data["o"],), active)
        gm, gs = _moments((data["ag"], data["g"]), active)
        return cls(om, os, gm, gs, len(active), clip)

    def observations(self, values):
        return np.clip((values - self.obs_mean) / self.obs_std, -self.clip, self.clip).astype(np.float32)

    def goals(self, values):
        return np.clip((values - self.goal_mean) / self.goal_std, -self.clip, self.clip).astype(np.float32)

    def as_dict(self):
        return {key: value.tolist() if isinstance(value, np.ndarray) else value
                for key, value in vars(self).items()}


class EpisodeSampler:
    def __init__(self, data, sources, probabilities, seed, threshold, normalizer=None):
        validate_buffer(data)
        self.data = data
        self.n, self.h = data["o"].shape[:2]
        self.sources = np.asarray(sources)
        self.p = np.asarray(probabilities, dtype=np.float64)
        if (self.sources.shape != (self.n,) or not np.isin(self.sources, [0, 1]).all()
                or self.p.shape != (self.n,) or not np.isfinite(self.p).all()
                or (self.p < 0).any() or self.p.sum() <= 0 or threshold <= 0):
            raise ValueError("Invalid source, support probability or threshold")
        self.p = self.p / self.p.sum()
        self.rng = np.random.default_rng(seed)
        self.threshold = threshold
        self.normalizer = normalizer
        self.exposure = {}
        self._entries = None

    def _draw(self, size, observations=False):
        return self.rng.choice(self.n, size=size, p=self.p), self.rng.integers(
            self.h if observations else self.h - 1, size=size)

    def initial_examples(self):
        episode = int(np.flatnonzero(self.p > 0)[0])
        ids = np.array([episode])
        self._record("initialization", ids)
        return dict(episode=episode, observations=self._obs(self.data["o"][ids, 0]),
                    goals=self._goals(self.data["ag"][ids, 0]),
                    actions=self.data["u"][ids, 0].astype(np.float32))

    def _record(self, name, episode):
        self.exposure.setdefault(name, np.zeros(self.n, dtype=np.int64))
        self.exposure[name] += np.bincount(episode, minlength=self.n)

    def _obs(self, values):
        return self.normalizer.observations(values) if self.normalizer else values.astype(np.float32)

    def _goals(self, values):
        return self.normalizer.goals(values) if self.normalizer else values.astype(np.float32)

    def _future(self, times, geometric, discount):
        if geometric:
            return np.minimum(times + self.rng.geometric(1 - discount, len(times)), self.h - 1)
        low = np.minimum(times + 1, self.h - 1)
        return np.rint(low + self.rng.random(len(times)) * (self.h - 1 - low)).astype(int)

    def _goal_indices(self, episodes, times, cur, traj, random, geometric, discount):
        if min(cur, traj, random) < 0 or not np.isclose(cur + traj + random, 1):
            raise ValueError("Goal sampling probabilities must sum to one")
        other_episode, other_time = self._draw(len(times), observations=True)
        future = self._future(times, geometric, discount)
        if cur == 1:
            return episodes.copy(), times.copy()
        is_traj = self.rng.random(len(times)) < traj / (1 - cur)
        goal_episode = np.where(is_traj, episodes, other_episode)
        goal_time = np.where(is_traj, future, other_time)
        is_cur = self.rng.random(len(times)) < cur
        return np.where(is_cur, episodes, goal_episode), np.where(is_cur, times, goal_time)

    def sample_ogbench(self, size, config, hierarchical=False):
        ep, t = self._draw(size)
        ge, gt = self._goal_indices(ep, t, config["value_p_curgoal"], config["value_p_trajgoal"],
                                    config["value_p_randomgoal"], config["value_geom_sample"],
                                    config["discount"])
        raw_goal = self.data["ag"][ge, gt]
        success = (np.linalg.norm(self.data["ag"][ep, t] - raw_goal, axis=-1) < self.threshold).astype(np.float32)
        batch = {"observations": self._obs(self.data["o"][ep, t]),
                 "next_observations": self._obs(self.data["o"][ep, t + 1]),
                 "actions": self.data["u"][ep, t].astype(np.float32),
                 "value_goals": self._goals(raw_goal), "masks": 1 - success,
                 "rewards": success - float(config["gc_negative"])}
        audit = {"episode": ep, "time": t, "value_goal_episode": ge, "value_goal_time": gt}
        if hierarchical:
            low_time = np.minimum(t + config["subgoal_steps"], self.h - 1)
            future = self._future(t, config["actor_geom_sample"], config["discount"])
            random_ep, random_t = self._draw(size, observations=True)
            is_random = self.rng.random(size) < config["actor_p_randomgoal"]
            if config["actor_p_curgoal"] != 0:
                raise ValueError("Hierarchical reference adapter requires zero current actor-goal probability")
            high_ep, high_t = np.where(is_random, random_ep, ep), np.where(is_random, random_t, future)
            target_t = np.where(is_random, low_time, np.minimum(low_time, future))
            batch.update(low_actor_goals=self._goals(self.data["ag"][ep, low_time]),
                         high_actor_goals=self._goals(self.data["ag"][high_ep, high_t]),
                         high_actor_targets=self._goals(self.data["ag"][ep, target_t]),
                         high_actor_target_observations=self._obs(self.data["o"][ep, target_t]))
            audit.update(high_goal_episode=high_ep, high_goal_time=high_t, high_target_time=target_t)
            self._record("high_goals", high_ep)
        else:
            ae, at = self._goal_indices(ep, t, config["actor_p_curgoal"], config["actor_p_trajgoal"],
                                        config["actor_p_randomgoal"], config["actor_geom_sample"],
                                        config["discount"])
            batch["actor_goals"] = self._goals(self.data["ag"][ae, at])
            audit.update(actor_goal_episode=ae, actor_goal_time=at)
            self._record("actor_goals", ae)
        self._record("transitions", ep)
        self._record("value_goals", ge)
        return batch, audit

    def _smore_batch(self, episodes, times, goals):
        obs = self._obs(self.data["o"][episodes, times])
        next_obs = self._obs(self.data["o"][episodes, times + 1])
        goal = self._goals(goals)
        success = (np.linalg.norm(self.data["ag"][episodes, times + 1] - goals, axis=-1) < self.threshold)
        return dict(observations=np.concatenate((obs, goal), axis=-1),
                    next_observations=np.concatenate((next_obs, goal), axis=-1),
                    actions=self.data["u"][episodes, times].astype(np.float32),
                    achieved_goals=self._goals(self.data["ag"][episodes, times]),
                    goals=goal, rewards=success.astype(np.float32) - 1)

    def _goal_entries(self):
        if self._entries is None:
            active = np.flatnonzero(self.p > 0)
            episodes, times = [], []
            for ids in np.array_split(active, max(1, len(active) // 128)):
                success = np.linalg.norm(self.data["ag"][ids, 1:] - self.data["g"][ids], axis=-1) < self.threshold
                local_ep, time = np.nonzero(success)
                episodes.append(ids[local_ep])
                times.append(time)
            ep, t = np.concatenate(episodes), np.concatenate(times)
            probabilities = self.p[ep]
            if len(probabilities):
                probabilities = probabilities / probabilities.sum()
            self._entries = ep, t, probabilities
        return self._entries

    def sample_smore(self, size, p_future=.8):
        if not 0 <= p_future <= 1:
            raise ValueError("Invalid future-goal probability")
        ep, t = self._draw(size)
        future_t = t + 1 + (self.rng.random(size) * (self.h - 1 - t)).astype(int)
        goals = self.data["g"][ep, t].copy()
        her = self.rng.random(size) < p_future
        goals[her] = self.data["ag"][ep[her], future_t[her]]
        regular = self._smore_batch(ep, t, goals)
        regular["is_expert"] = (self.sources[ep] == 0).astype(np.float32)
        aux_ep, aux_base = self._draw(size)
        aux_future = aux_base + 1 + (self.rng.random(size) * (self.h - 1 - aux_base)).astype(int)
        aux_t = aux_future - 1
        aux_goals = self.data["ag"][aux_ep, aux_future].copy()
        use_original = self.rng.random(size) >= p_future
        if use_original.any():
            entries_ep, entries_t, probabilities = self._goal_entries()
            if not len(entries_ep):
                raise ValueError("No active original-goal goal-entry transitions; cannot silently change auxiliary mixture")
            chosen = self.rng.choice(len(entries_ep), size=use_original.sum(), p=probabilities)
            aux_ep[use_original] = entries_ep[chosen]
            aux_t[use_original] = entries_t[chosen]
            aux_goals[use_original] = self.data["g"][entries_ep[chosen], entries_t[chosen]]
        auxiliary = self._smore_batch(aux_ep, aux_t, aux_goals)
        self._record("transitions", ep)
        self._record("goal_entry", aux_ep)
        audit = dict(episode=ep, time=t, future_time=future_t, her=her,
                     aux_episode=aux_ep, aux_time=aux_t, aux_original_goal=use_original)
        return regular, auxiliary, audit

    def exposure_summary(self):
        return {name: {"draws": int(counts.sum()), "unique_episodes": int((counts > 0).sum()),
                       "zero_support_draws": int(counts[self.p == 0].sum()),
                       "expert_draw_fraction": float(counts[self.sources == 0].sum() / counts.sum())}
                for name, counts in self.exposure.items() if counts.sum()}
