"""Checked index views for candidate controls; no copied or implicit new support."""

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from revision.audit_sources import sha256
from revision.measurements import ternary_labels


@dataclass(frozen=True)
class ControlSelection:
    ids: np.ndarray
    probabilities: np.ndarray
    slot_indices: np.ndarray | None
    labels: dict
    metadata: dict


def _integer_vector(values, name, length=None):
    values = np.asarray(values)
    if values.ndim != 1 or not np.issubdtype(values.dtype, np.integer):
        raise ValueError(f"Invalid integer {name}")
    if length is not None and len(values) != length:
        raise ValueError(f"Wrong length for {name}")
    return values


def load_control_selection(cohort_path, condition_path, labels_path, arm, task, data_seed):
    cohort_path, condition_path, labels_path = map(Path, (cohort_path, condition_path, labels_path))
    if arm not in ("weighted", "fixed_size"):
        raise ValueError("Unknown control arm")
    if cohort_path.parent.resolve() != condition_path.parent.resolve():
        raise ValueError("Condition and cohort must belong to the same audit")
    audit_path = cohort_path.parent / "audit.json"
    audit = json.loads(audit_path.read_text())
    if audit["task"] != task or audit["data_seed"] != data_seed:
        raise ValueError("Control task or data seed disagrees with job")
    rows = [row for row in audit["candidate_controls"] if row.get("manifest") == condition_path.name]
    if len(rows) != 1 or not rows[0]["feasible"]:
        raise ValueError("Missing unique feasible audited condition")
    row = rows[0]
    if sha256(condition_path) != row["manifest_sha256"] or sha256(labels_path) != audit["source_label_artifact_sha256"]:
        raise ValueError("Control artifact hash changed")
    with np.load(cohort_path, allow_pickle=False) as cohort:
        global_ids = _integer_vector(cohort["global_ids"], "global ids")
        n = len(global_ids)
        source = _integer_vector(cohort["source"], "source", n)
        episode = _integer_vector(cohort["source_episode"], "source episode", n)
    ids = np.column_stack((source, episode)).astype(np.int64)
    if (not n or np.any(episode < 0) or not np.isin(source, [0, 1]).all()
            or len(np.unique(global_ids)) != n or len(np.unique(ids, axis=0)) != n):
        raise ValueError("Cohort must contain distinct valid original episode ids")
    if hashlib.sha256(global_ids.tobytes()).hexdigest() != audit["cohort_global_ids_sha256"]:
        raise ValueError("Cohort index hash changed")
    with np.load(labels_path, allow_pickle=False) as raw:
        if np.any(global_ids < 0) or np.any(global_ids >= len(raw["source"])):
            raise ValueError("Cohort outside audited label support")
        if not np.array_equal(raw["source"][global_ids], source) or not np.array_equal(raw["source_episode"][global_ids], episode):
            raise ValueError("Cohort source coordinates disagree with label audit")
        if np.intersect1d(global_ids, raw["measurement_reference_ids"]).size or not audit["reference_disjoint"]:
            raise ValueError("Measurement reference leaks into training cohort")
        labels = {key.removeprefix("label_"): raw[key][global_ids] for key in raw.files if key.startswith("label_")}
        quality = {key.removeprefix("quality_"): raw[key][global_ids] for key in raw.files if key.startswith("quality_")}
    with np.load(condition_path, allow_pickle=False) as manifest:
        p = np.asarray(manifest["episode_probabilities"], dtype=np.float64)
        indices = _integer_vector(manifest["indices"], "stored slots", n)
    if (p.shape != (n,) or not np.isfinite(p).all() or np.any(p < 0)
            or not np.isclose(p.sum(), 1., rtol=0, atol=1e-12)
            or np.any(indices < 0) or np.any(indices >= n)):
        raise ValueError("Invalid control probabilities or stored slot coordinates")
    slots = indices.copy() if arm == "fixed_size" else None
    if slots is not None:
        p = np.bincount(slots, minlength=n).astype(np.float64) / n
    target = labels[row["axis"]] == row["level"]
    if row["control"] == "source_only":
        strata = source[:, None]
    elif row["control"] == "quality_cross_axis":
        return_group = ternary_labels(quality["native_return"], audit["return_thresholds"])
        strata = np.column_stack((source, quality["final_success"], return_group,
                                  *[value for key, value in labels.items() if key != row["axis"]]))
    else:
        raise ValueError("Unknown audited balancing variables")
    _, inverse, cell_counts = np.unique(strata, axis=0, return_inverse=True, return_counts=True)
    if not np.allclose(np.bincount(inverse, weights=p), cell_counts / n, rtol=0, atol=1e-12):
        raise ValueError("Control changed required joint-stratum mass")
    attained = float(p @ target)
    expected = row["weighted" if arm == "weighted" else "fixed"]["attained_fraction"]
    if not np.isclose(attained, expected, rtol=0, atol=1e-12):
        raise ValueError("Actual target prevalence disagrees with audited condition")
    intervention = row.get("intervention", "target_vs_complement")
    category_fractions = np.bincount(labels[row["axis"]], weights=p, minlength=3)
    if intervention == "reciprocal_middle_fixed":
        if row["level"] != 2:
            raise ValueError("Reciprocal category exchange requires the declared high level")
        middle = labels[row["axis"]] == 1
        if not np.allclose(p[middle], 1 / n, rtol=0, atol=1e-12):
            raise ValueError("Reciprocal view changed individual middle-episode mass")
        declared = row["weighted" if arm == "weighted" else "fixed"]["attained_category_fractions"]
        if not np.allclose(category_fractions, declared, rtol=0, atol=1e-12):
            raise ValueError("Actual reciprocal category fractions disagree with the audit")
    elif intervention != "target_vs_complement":
        raise ValueError("Unknown audited composition intervention")
    source_counts = np.bincount(source, minlength=2)
    if not np.array_equal(source_counts, audit["source_counts"]):
        raise ValueError("Original source quotas disagree with audit")
    hashes = {"cohort": sha256(cohort_path), "condition": sha256(condition_path),
              "labels": sha256(labels_path), "audit": sha256(audit_path)}
    metadata = dict(arm=arm, task=task, data_seed=data_seed, axis=row["axis"], level=row["level"],
                    intervention=intervention, category_exposure_fractions=category_fractions.tolist(),
                    balancing=row["control"], natural_fraction=float(target.mean()),
                    requested_fraction=row["requested_fraction"], target_exposure_fraction=attained,
                    stored_episodes=n, active_unique_episodes=int((p > 0).sum()),
                    repeated_copies=int(n - (p > 0).sum()) if slots is not None else 0,
                    source_exposure_fractions=np.bincount(source, weights=p, minlength=2).tolist(),
                    probabilities_sha256=hashlib.sha256(p.tobytes()).hexdigest(), hashes=hashes,
                    reference_disjoint=True, candidate_not_confirmatory=True,
                    fixed_size_representation="Uniform logical stored slots represented by original-id multiplicities; no duplicate arrays",
                    normalization_support="Each positive-probability original episode once, independent of weight or multiplicity")
    return ControlSelection(ids, p, slots, labels, metadata)


def selection_for_config(config, default_ids):
    stage = config["stage"]
    controlled = stage in ("modern_control_validation", "control_validation", "confirmatory", "frozen_runner_validation")
    if not controlled and "control" not in config:
        return default_ids, None
    if not controlled or "control" not in config:
        raise ValueError("Control configuration requires a checked controlled stage")
    if config.get("normalization") != "reference_support":
        raise ValueError("Controlled validation requires frozen reference-support normalization")
    spec = config["control"]
    control = load_control_selection(spec["cohort"], spec["condition"], spec["labels"], spec["arm"],
                                     config["task"], config["data_seed"])
    if len(control.ids) != config["episodes"]:
        raise ValueError("Control cohort size disagrees with the configured budget")
    return control.ids, control


def control_exposure_summary(control, paths):
    n = len(control.ids)
    target = control.labels[control.metadata["axis"]] == control.metadata["level"]
    result = {}
    for name, raw in paths.items():
        counts = _integer_vector(raw, f"exposure for {name}", n)
        if np.any(counts < 0):
            raise ValueError("Negative exposure counts")
        if counts[control.probabilities == 0].sum():
            raise ValueError(f"Actual zero-support exposure in {name}")
        draws = int(counts.sum())
        if not draws:
            continue
        result[name] = dict(draws=draws, active_drawn_episodes=int((counts > 0).sum()),
                            zero_support_draws=0, target_fraction=float(counts[target].sum() / draws),
                            source_fractions=(np.bincount(control.ids[:, 0], weights=counts, minlength=2) / draws).tolist(),
                            type_fractions={axis: (np.bincount(value, weights=counts, minlength=3) / draws).tolist()
                                            for axis, value in control.labels.items()})
    return result
