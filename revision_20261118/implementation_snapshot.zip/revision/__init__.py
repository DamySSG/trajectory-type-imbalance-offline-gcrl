"""Auditable major-revision experiments, separate from historical runs."""
