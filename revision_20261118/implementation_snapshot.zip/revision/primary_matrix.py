"""Bounded main-study candidate; freezing and launch require separate actual gates."""

import argparse
from pathlib import Path, PurePosixPath

from revision.queue import stamp, write_json


METHODS = ("gcsl", "wgcsl", "ddpg", "gofar", "hiql", "crl", "smore")
AXES = ("goal_separation", "spatial_support", "action_direction")
SEEDS = (11, 29, 47)


def primary_matrix(root, tag="v17"):
    baselines, interventions = [], []
    for task in ("FetchPush", "PointMaze"):
        for method in METHODS:
            modern = method in ("hiql", "crl", "smore")
            for seed in SEEDS:
                cohort = root / "audit/mixture_and_dose_controls_v1/mixture_50" / f"{task}_d{seed+1000}"
                base_id = f"main-{tag}-{task}-{method}-natural-s{seed}"
                common = dict(task=task, method=method, seed=seed, data_seed=seed+1000, stage="confirmatory",
                    purpose="confirmatory_primary_matched_composition", episodes=10000,
                    normalization="reference_support", updates=200000 if modern else 100000,
                    epochs=500, n_cycles=10, n_batches=20, eval_rollouts=32,
                    eval_interval=20000 if modern else 50,
                    batch_size=256 if method == "smore" else 1024 if modern else 512,
                    evaluation_discount=.99, checkpoint_policy="final_only")
                control = dict(cohort=str(cohort / "cohort.npz"),
                               labels=str(root / "audit/measurements_v1" / f"labels_{task}.npz"))
                baselines.append(dict(**common, id=base_id, depends_on=[], variant=dict(kind="natural"),
                    control=dict(**control, arm="weighted",
                                 condition=str(cohort / "goal_separation_level0_quality_cross_axis_delta+0.00.npz"))))
                for axis in AXES:
                    for level in (0, 2):
                        for change in (-.10, .10):
                            for arm in ("weighted", "fixed_size"):
                                interventions.append(dict(**common,
                                    id=f"main-{tag}-{task}-{method}-{axis}-l{level}-d{change:+.2f}-{arm}-s{seed}",
                                    depends_on=[base_id], variant=dict(kind="intervention", axis=axis,
                                                                     level=level, change=change, arm=arm),
                                    control=dict(**control, arm=arm,
                                        condition=str(cohort / f"{axis}_level{level}_quality_cross_axis_delta{change:+.2f}.npz"))))
    return baselines + interventions


def comparison_families(jobs):
    baselines = {(job["task"], job["method"], job["seed"]): job["id"] for job in jobs
                 if job["variant"]["kind"] == "natural"}
    conditions = {(job["task"], job["method"], job["variant"]["axis"], job["variant"]["level"],
                   job["variant"]["change"], job["variant"]["arm"], job["seed"]): job["id"]
                  for job in jobs if job["variant"]["kind"] == "intervention"}
    families = []
    for task in ("FetchPush", "PointMaze"):
        for arm in ("weighted", "fixed_size", "arm_difference"):
            contrasts = []
            for method in METHODS:
                for axis in AXES:
                    for level in (0, 2):
                        for change in (-.10, .10):
                            pairs = []
                            for seed in SEEDS:
                                point = task, method, axis, level, change
                                condition = conditions[(*point, "fixed_size" if arm == "arm_difference" else arm, seed)]
                                reference = (conditions[(*point, "weighted", seed)] if arm == "arm_difference" else
                                             baselines[task, method, seed])
                                pairs.append(dict(seed=seed, condition=condition, reference=reference))
                            contrasts.append(dict(id=f"{task}-{method}-{axis}-l{level}-d{change:+.2f}-{arm}",
                                                  pairs=pairs, method=method, axis=axis, level=level, change=change))
            families.append(dict(id=f"primary_{task}_{arm}" if arm != "arm_difference" else f"secondary_{task}_arms",
                role="secondary" if arm == "arm_difference" else "primary", endpoint="final_success",
                estimand="fixed_size_minus_weighted" if arm == "arm_difference" else "condition_minus_same_seed_natural",
                multiplicity="Holm within this prespecified task/arm family", contrasts=contrasts,
                replication_unit="Three paired learner/data-seed blocks, not conditions, episodes or checkpoints",
                statistic="Individual paired effects, mean/SD, explicitly model-dependent t95 interval and exact sign flip",
                exact_test_minimum_two_sided_p=.25, nonrejection_is_not_equivalence=True))
    return families


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    jobs = primary_matrix(PurePosixPath(args.remote_root))
    write_json(args.output / "candidate_matrix.json", jobs)
    write_json(args.output / "candidate_comparisons.json", comparison_families(jobs))
    write_json(args.output / "candidate_status.json", dict(created=stamp(), jobs=len(jobs),
        natural_baselines=42, interventions=1008, status="candidate_not_frozen_not_queued",
        scientific_gates_complete=False, final_test_outcomes_used=False,
        dose_origin="Largest audited common +/-0.10 support-feasible change; no policy effect used",
        extra_study_packages_not_included=["source-only controls", "support removal", "reciprocal composition",
                                           "source-mixture and threshold sensitivities", "additional tasks"],
        freezing_requires="Actual baseline and runner audits, code/data/bank hashes, compute/disk forecast, all comparison families"))


if __name__ == "__main__":
    main()
