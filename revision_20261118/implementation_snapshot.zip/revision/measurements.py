"""Explicit observables for goal geometry, spatial support, and action direction."""

import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra
from scipy.spatial import cKDTree


def goal_separation(start, goal, route_distance=None):
    start, goal = np.asarray(start), np.asarray(goal)
    if start.shape != goal.shape or start.ndim != 2 or not np.isfinite([start, goal]).all():
        raise ValueError("Goal-coordinate shapes or finite values are invalid")
    return np.linalg.norm(start - goal, axis=-1) if route_distance is None else route_distance(start, goal)


def ternary_labels(scores, thresholds):
    scores = np.asarray(scores)
    lower, upper = thresholds
    if scores.ndim != 1 or not np.isfinite(scores).all() or not np.isfinite(thresholds).all() or lower > upper:
        raise ValueError("Invalid scores or frozen thresholds")
    return np.where(scores <= lower, 0, np.where(scores < upper, 1, 2)).astype(np.int8)


def action_bias(actions, neutral_tolerance=.05):
    actions = np.asarray(actions)
    if (actions.ndim != 3 or actions.shape[-1] < 2 or not np.isfinite(actions).all() or
            not np.isfinite(neutral_tolerance) or not 0 <= neutral_tolerance <= 1):
        raise ValueError("Invalid planar actions or neutral tolerance")
    planar = actions[..., :2].astype(np.float64)
    denominator = np.linalg.norm(planar, axis=-1).sum(axis=1)
    score = np.divide(planar[..., 0].sum(axis=1), denominator, out=np.zeros(len(actions)),
                      where=denominator > 1e-12)
    score = np.clip(score, -1, 1)
    label = np.where(score < -neutral_tolerance, 0, np.where(score > neutral_tolerance, 2, 1))
    return score, label.astype(np.int8)


class GridRouteDistance:
    """Wall-aware finite-grid shortest routes, not exact continuous geodesics."""

    def __init__(self, maze_map, cell_size, subdivisions=10):
        if (not np.isfinite(cell_size) or cell_size <= 0 or not isinstance(subdivisions, int)
                or subdivisions < 1):
            raise ValueError("Invalid maze grid scale")
        original = np.asarray(maze_map, dtype=object)
        if original.ndim != 2:
            raise ValueError("Maze must be a rectangular map")
        self.free = np.repeat(np.repeat(original != 1, subdivisions, axis=0), subdivisions, axis=1)
        self.step = cell_size / subdivisions
        self.x_center = original.shape[1] * cell_size / 2
        self.y_center = original.shape[0] * cell_size / 2
        self.index = np.full(self.free.shape, -1, dtype=int)
        r, c = np.nonzero(self.free)
        self.index[r, c] = np.arange(len(r))
        self.points = np.column_stack(((c + .5) * self.step - self.x_center,
                                       self.y_center - (r + .5) * self.step))
        rows, columns, costs = [], [], []
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1),
                       (-1, -1), (-1, 1), (1, -1), (1, 1)):
            nr, nc = r + dr, c + dc
            valid = (nr >= 0) & (nr < self.free.shape[0]) & (nc >= 0) & (nc < self.free.shape[1])
            ids = np.flatnonzero(valid)
            ids = ids[self.free[nr[ids], nc[ids]]]
            if dr and dc:
                ids = ids[self.free[r[ids] + dr, c[ids]] & self.free[r[ids], c[ids] + dc]]
            rows.append(self.index[r[ids], c[ids]])
            columns.append(self.index[nr[ids], nc[ids]])
            costs.append(np.full(len(ids), self.step * np.hypot(dr, dc)))
        self.graph = csr_matrix((np.concatenate(costs), (np.concatenate(rows), np.concatenate(columns))),
                                shape=(len(r), len(r)))

    def _snap(self, points):
        r = np.floor((self.y_center - points[:, 1]) / self.step).astype(int)
        c = np.floor((points[:, 0] + self.x_center) / self.step).astype(int)
        if ((r < 0).any() or (r >= self.free.shape[0]).any() or (c < 0).any() or
                (c >= self.free.shape[1]).any()):
            raise ValueError("Point outside maze map")
        ids = self.index[r, c]
        if (ids < 0).any():
            raise ValueError("Point inside a wall cell")
        return ids

    def __call__(self, start, goal):
        start, goal = np.asarray(start), np.asarray(goal)
        if start.shape != goal.shape or start.ndim != 2 or start.shape[-1] != 2 or not np.isfinite([start, goal]).all():
            raise ValueError("Invalid maze coordinate pairs")
        a, b = self._snap(start), self._snap(goal)
        unique, inverse = np.unique(a, return_inverse=True)
        result = np.empty(len(start))
        for low in range(0, len(unique), 128):
            high = min(low + 128, len(unique))
            distances = dijkstra(self.graph, directed=False, indices=unique[low:high])
            mask = (inverse >= low) & (inverse < high)
            result[mask] = distances[inverse[mask] - low, b[mask]]
        result += np.linalg.norm(start - self.points[a], axis=-1) + np.linalg.norm(goal - self.points[b], axis=-1)
        same = a == b
        result[same] = np.linalg.norm(start[same] - goal[same], axis=-1)
        return result


class SpatialSupportReference:
    """Mean kNN radius at trajectory positions, with same-episode exclusion."""

    def __init__(self, points, episode_ids, k=8):
        points, ids = np.asarray(points, dtype=np.float64), np.asarray(episode_ids)
        if (points.ndim != 2 or ids.shape != (len(points),) or not np.isfinite(points).all()
                or not isinstance(k, int) or k < 1):
            raise ValueError("Invalid density reference")
        _, counts = np.unique(ids, return_counts=True)
        self.max_per_episode = int(counts.max())
        if len(points) - self.max_per_episode < k:
            raise ValueError("Too few neighbors after same-episode exclusion")
        self.mean = points.mean(axis=0)
        self.scale = np.maximum(points.std(axis=0), 1e-3)
        self.ids, self.k = ids, k
        self.points = points
        self.tree = cKDTree((points - self.mean) / self.scale)

    def score(self, trajectories, episode_ids):
        trajectories, episode_ids = np.asarray(trajectories), np.asarray(episode_ids)
        if (trajectories.ndim != 3 or trajectories.shape[-1] != len(self.mean) or
                episode_ids.shape != (len(trajectories),) or not np.isfinite(trajectories).all()):
            raise ValueError("Invalid trajectory density coordinates")
        score = np.empty(len(trajectories))
        for low in range(0, len(trajectories), 128):
            query = trajectories[low:low + 128]
            flat = ((query - self.mean) / self.scale).reshape(-1, len(self.mean))
            distances, neighbor = self.tree.query(flat, k=self.k + self.max_per_episode, workers=1)
            query_ids = np.repeat(episode_ids[low:low + 128], query.shape[1])
            distances[self.ids[neighbor] == query_ids[:, None]] = np.inf
            radii = np.partition(distances, self.k - 1, axis=1)[:, :self.k].mean(axis=1)
            score[low:low + len(query)] = radii.reshape(len(query), -1).mean(axis=1)
        return score
