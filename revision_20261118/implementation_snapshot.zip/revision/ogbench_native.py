"""Native full-state goals with explicit task-success geometry for OGBench."""

import numpy as np


ENVIRONMENTS = {'AntMazeLarge': 'antmaze-large-navigate-v0',
                'CubeDouble': 'cube-double-play-v0'}


class StableActionSpaceMixin:
    @property
    def action_space(self):
        if not hasattr(self, '_seeded_native_action_space'):
            self._seeded_native_action_space = super().action_space
        return self._seeded_native_action_space


def _repeatable_cube_native():
    from ogbench.manipspace.envs.cube_env import CubeEnv

    class RepeatableCubeEnv(StableActionSpaceMixin, CubeEnv):
        pass

    return RepeatableCubeEnv


def position_projection(task, values):
    values = np.asarray(values)
    if task == 'AntMazeLarge':
        if values.shape[-1] != 29:
            raise ValueError('Ant native state/goal dimension changed')
        return values[..., :2]
    if task == 'CubeDouble':
        if values.shape[-1] != 37:
            raise ValueError('Double-cube native state/goal dimension changed')
        scaled = np.concatenate((values[..., 19:22], values[..., 28:31]), axis=-1)
        return scaled / 10.0 + np.tile([.425, 0., 0.], 2)
    raise ValueError('Unspecified OGBench task')


def native_success(task, achieved, desired):
    a, g = position_projection(task, achieved), position_projection(task, desired)
    if a.shape != g.shape:
        raise ValueError('Goal shapes disagree')
    if task == 'AntMazeLarge':
        return np.linalg.norm(a - g, axis=-1) <= .5
    return (np.linalg.norm((a - g).reshape(*a.shape[:-1], 2, 3), axis=-1) <= .04).all(axis=-1)


class NativeGoalEnv:
    """Keep the native state goal; expose the existing learner dictionary API."""

    def __init__(self, task, collection=False, native=None):
        if task not in ENVIRONMENTS:
            raise ValueError('Unspecified OGBench task')
        if native is None:
            import ogbench
            native = ogbench.make_env_and_datasets(ENVIRONMENTS[task], env_only=True,
                terminate_at_goal=not collection)
            if task == 'CubeDouble':
                import copy
                import gymnasium as gym
                spec = copy.deepcopy(native.spec)
                native.close()
                spec.entry_point = _repeatable_cube_native()
                native = gym.make(spec)
        self.task, self.native, self.collection = task, native, collection
        self.spec, self.action_space = native.spec, native.action_space
        self.goal = None

    @property
    def unwrapped(self):
        return self.native.unwrapped

    def _observation(self, observation):
        value = np.asarray(observation).copy()
        position_projection(self.task, value)
        if self.goal is None or value.shape != self.goal.shape:
            raise ValueError('Native goal and observation contracts disagree')
        return dict(observation=value, achieved_goal=value.copy(), desired_goal=self.goal.copy())

    def reset(self, seed=None, options=None):
        state = np.random.get_state()
        try:
            if seed is not None:
                np.random.seed(int(seed))
                self.native.unwrapped.np_random = np.random.default_rng(int(seed))
                self.action_space.seed(int(seed))
            observation, info = self.native.reset(seed=seed, options=options)
        finally:
            np.random.set_state(state)
        if 'goal' not in info:
            raise ValueError('Native environment did not provide its actual goal')
        self.goal = np.asarray(info['goal']).copy()
        return self._observation(observation), info

    def step(self, action):
        observation, reward, terminated, truncated, info = self.native.step(action)
        success = native_success(self.task, observation, self.goal)
        if float(info['success']) != float(success) or float(reward) != float(success):
            raise ValueError('Native post-action success/reward disagrees with geometry')
        return self._observation(observation), reward, terminated, truncated, info

    def compute_reward(self, achieved, desired, info):
        return native_success(self.task, achieved, desired).astype(np.float32)

    def close(self):
        self.native.close()
