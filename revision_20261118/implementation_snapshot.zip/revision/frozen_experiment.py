"""Immutable scientific job and reset-bank gates; no unvalidated job restoration."""

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from revision.audit_sources import sha256
from revision.job_checkpoint import digest, scientific_config


@dataclass(frozen=True)
class EvaluationBank:
    seeds: np.ndarray
    observations: dict
    sha256: str

    @classmethod
    def load(cls, path, expected_hash, count):
        path = Path(path)
        if sha256(path) != expected_hash:
            raise ValueError("Evaluation bank hash changed")
        with np.load(path, allow_pickle=False) as raw:
            if set(raw.files) != {"reset_seeds", "observation", "achieved_goal", "desired_goal"}:
                raise ValueError("Unknown evaluation bank schema")
            seeds = raw["reset_seeds"].copy()
            observations = {key: raw[key].copy() for key in raw.files if key != "reset_seeds"}
        if seeds.ndim != 1 or seeds.dtype.kind not in "iu" or len(seeds) != count or count < 1:
            raise ValueError("Invalid evaluation bank count or seeds")
        if len(np.unique(seeds)) != count or any(value.ndim != 2 or value.shape[0] != count or
                                                not np.isfinite(value).all() for value in observations.values()):
            raise ValueError("Invalid evaluation bank observations")
        for value in [seeds, *observations.values()]:
            value.setflags(write=False)
        return cls(seeds, observations, expected_hash)

    def verify_reset(self, index, observation):
        if set(observation) != set(self.observations) or any(
                not np.array_equal(np.asarray(observation[key]), values[index])
                for key, values in self.observations.items()):
            raise ValueError(f"Actual environment reset disagrees with frozen bank case {index}")


def registered_config(config):
    return scientific_config({key: value for key, value in config.items() if key != "frozen_protocol"})


def validate_frozen_job(config, worker_code=None):
    anchor = config.get("frozen_protocol")
    if not anchor or set(anchor) != {"path", "sha256", "job_key"}:
        raise ValueError("Missing frozen protocol anchor")
    path = Path(anchor["path"])
    if sha256(path) != anchor["sha256"]:
        raise ValueError("Frozen protocol hash changed")
    protocol = json.loads(path.read_text())
    if protocol.get("format_version") not in (1, 2):
        raise ValueError("Unsupported frozen protocol format")
    stages = {"frozen_confirmatory": "confirmatory",
              "implementation_validation_not_confirmatory": "frozen_runner_validation"}
    if protocol.get("status") not in stages or config.get("stage") != stages[protocol["status"]]:
        raise ValueError("Job stage disagrees with frozen protocol status")
    if protocol.get("production_resume_allowed") is not False:
        raise ValueError("Production resume is unvalidated and prohibited")
    seeds, data_seeds = protocol.get("learner_seeds"), protocol.get("data_seeds")
    if seeds != [11, 29, 47] or data_seeds != [1011, 1029, 1047] or (
            config.get("seed"), config.get("data_seed")) not in zip(seeds, data_seeds):
        raise ValueError("Invalid learner/data seed block")
    if (protocol.get("primary_endpoint") != "final_success" or
            protocol.get("secondary_endpoints") != ["ever_success", "native_return"] or
            protocol.get("checkpoint_policy") != "final_only" or config.get("checkpoint_policy") != "final_only" or
            protocol.get("evaluation_discount") != .99 or config.get("evaluation_discount") != .99):
        raise ValueError("Changed endpoint, checkpoint or evaluation discount")
    spec = protocol.get("evaluation_banks", {}).get(config.get("task"))
    if spec is None:
        raise ValueError("Missing task evaluation bank")
    bank = EvaluationBank.load(spec["path"], spec["sha256"], spec["episodes"])
    confirmatory = protocol["status"] == "frozen_confirmatory"
    if confirmatory:
        if len(bank.seeds) != 1024 or not np.array_equal(bank.seeds, np.arange(1900000, 1901024)):
            raise ValueError("Wrong final-test bank")
        if not all(protocol.get("gates", {}).get(key) is True for key in
                   ("data_and_measurements", "baseline_validation", "runner_validation", "bounded_forecast")):
            raise ValueError("Required scientific gates are incomplete")
        if protocol["format_version"] != 2 or not protocol.get("protected_artifacts"):
            raise ValueError("Confirmatory provenance metadata must be explicitly bound")
    elif np.intersect1d(bank.seeds, np.arange(1900000, 1901024)).size:
        raise ValueError("Implementation tests must not use the held-out final-test bank")
    protected = protocol.get("protected_artifacts", {})
    if not isinstance(protected, dict):
        raise ValueError("Invalid protected provenance artifact registry")
    for name, expected_hash in protected.items():
        if not isinstance(name, str) or not isinstance(expected_hash, str) or sha256(Path(name)) != expected_hash:
            raise ValueError("Protected provenance artifact changed")
    if not protocol.get("comparison_families") or not protocol.get("compute_forecast") or not protocol.get("storage_forecast"):
        raise ValueError("Missing comparison families or resource forecast")
    expected = protocol.get("jobs", {}).get(anchor["job_key"])
    if expected is None or digest(registered_config(config)) != expected:
        raise ValueError("Job scientific configuration is not the frozen registered configuration")
    budget = protocol.get("method_budgets", {}).get(config.get("method"))
    if budget is None or any(config.get(key) != value for key, value in budget.items()):
        raise ValueError("Changed method budget")
    if config["method"] in ("gcsl", "wgcsl", "ddpg", "gofar") and (
            config["updates"] != config["epochs"] * config["n_cycles"] * config["n_batches"]):
        raise ValueError("Legacy budget counters disagree")
    if config.get("normalization") != "reference_support" or "control" not in config:
        raise ValueError("Frozen experiments require explicit audited control and normalization")
    artifacts = protocol.get("artifacts", {})
    for artifact in (config["control"][key] for key in ("cohort", "condition", "labels")):
        if artifact not in artifacts or sha256(Path(artifact)) != artifacts[artifact]:
            raise ValueError("Frozen control artifact changed or was not registered")
    worker_code = Path(worker_code) if worker_code is not None else Path(__file__).resolve().parents[1]
    for name, expected_hash in protocol.get("worker_code_hashes", {}).items():
        source = worker_code / name
        if sha256(source) != expected_hash:
            raise ValueError("Frozen worker code changed")
    return dict(confirmatory=confirmatory, protocol_sha256=anchor["sha256"], job_key=anchor["job_key"],
                bank=bank, primary_endpoint=protocol["primary_endpoint"],
                comparison_families=protocol["comparison_families"])


def save_at_checkpoint(config, step, final_step):
    policy = config.get("checkpoint_policy", "all_evaluated")
    if policy not in ("all_evaluated", "final_only"):
        raise ValueError("Unsupported checkpoint selection rule")
    return policy == "all_evaluated" or step == final_step
