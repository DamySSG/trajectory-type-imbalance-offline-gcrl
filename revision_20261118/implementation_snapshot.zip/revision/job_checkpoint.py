"""Validated modern job snapshots; older snapshot formats are not resumable here."""

import copy
import hashlib
import json
import pickle
from pathlib import Path

import numpy as np


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def scientific_config(config):
    attempt_fields = {"id", "gpu", "physical_core", "created", "depends_on"}
    return {key: value for key, value in config.items() if key not in attempt_fields}


def probability_hash(sampler):
    return hashlib.sha256(sampler.p.astype("<f8").tobytes()).hexdigest()


def snapshot(agent, sampler, update, identity, metrics, evaluation_path=None):
    state = dict(format_version=2, agent_state=agent.state_bytes(),
                 sampler_rng=copy.deepcopy(sampler.rng.bit_generator.state),
                 exposure={key: value.copy() for key, value in sampler.exposure.items()},
                 updates=int(update), identity=identity, metrics=copy.deepcopy(metrics),
                 probability_sha256=probability_hash(sampler),
                 normalization=sampler.normalizer.as_dict() if sampler.normalizer else None)
    if evaluation_path is not None:
        prefix = Path(evaluation_path).read_bytes()
        state["evaluation_prefix"] = dict(path=str(Path(evaluation_path).resolve()),
                                          bytes=len(prefix), sha256=hashlib.sha256(prefix).hexdigest())
    return state


def restore(state, agent, sampler, identity):
    if state.get("format_version") != 2 or state.get("identity") != identity:
        raise ValueError("Unsupported checkpoint format or changed scientific identity")
    if state.get("probability_sha256") != probability_hash(sampler):
        raise ValueError("Changed sampling support/probabilities")
    norm = sampler.normalizer.as_dict() if sampler.normalizer else None
    if digest(state["normalization"]) != digest(norm):
        raise ValueError("Changed normalization identity")
    rng = np.random.default_rng()
    rng.bit_generator.state = state["sampler_rng"]
    exposure = {}
    for key, value in state["exposure"].items():
        value = np.asarray(value)
        if (value.shape != (sampler.n,) or value.dtype.kind not in "iu" or
                (value < 0).any() or value[sampler.p == 0].sum() != 0):
            raise ValueError("Invalid exposure state or zero-support exposure")
        exposure[key] = value.copy()
    if not isinstance(state["updates"], int) or state["updates"] < 0:
        raise ValueError("Invalid checkpoint update counter")
    agent.load_state_bytes(state["agent_state"])
    sampler.rng = rng
    sampler.exposure = exposure
    return dict(updates=state["updates"], metrics=copy.deepcopy(state["metrics"]))


def load_checkpoint(path):
    with Path(path).open("rb") as stream:
        state = pickle.load(stream)
    if state.get("format_version") != 2:
        raise ValueError("Older snapshots require their own tested restoration implementation")
    anchor = state.get("evaluation_prefix")
    prefix = b""
    if anchor:
        with Path(anchor["path"]).open("rb") as stream:
            prefix = stream.read(anchor["bytes"])
        if len(prefix) != anchor["bytes"] or hashlib.sha256(prefix).hexdigest() != anchor["sha256"]:
            raise ValueError("Checkpoint evaluation prefix changed or is incomplete")
    return state, prefix
