"""Outcome-independent, reference-disjoint mixture and dose construction audits."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from revision.audit_sources import sha256
from revision.balance_audit import fixed_stratified_indices, numeric_summary, stratified_probabilities
from revision.control_dataset import load_control_selection
from revision.measurements import ternary_labels
from revision.protocol import mixture_indices
from revision.queue import stamp, write_json


def build_cohort(labels_path, output, task, data_seed, total=10000, expert_fraction=.5,
                 changes=(0., -.05, .05, -.10, .10, -.15, .15)):
    labels_path, output = Path(labels_path), Path(output)
    output.mkdir(parents=True, exist_ok=False)
    with np.load(labels_path, allow_pickle=False) as raw:
        source, references = raw["source"], raw["measurement_reference_ids"]
        available = [np.flatnonzero((source == value) & ~np.isin(np.arange(len(source)), references))
                     for value in (0, 1)]
        pairs = mixture_indices(len(available[0]), len(available[1]), total, expert_fraction, data_seed)
        ids = np.where(pairs[:, 0] == 0, available[0][pairs[:, 1]], available[1][pairs[:, 1]])
        if len(np.unique(ids)) != total or np.intersect1d(ids, references).size:
            raise ValueError("Non-unique or reference-overlapping control cohort")
        episodes = raw["source_episode"][ids]
        labels = {key.removeprefix("label_"): raw[key][ids] for key in raw.files if key.startswith("label_")}
        quality = {key.removeprefix("quality_"): raw[key][ids] for key in raw.files if key.startswith("quality_")}
    quota = np.bincount(pairs[:, 0], minlength=2)
    if not np.array_equal(quota, [round(total * expert_fraction), total - round(total * expert_fraction)]):
        raise ValueError("Source selection quota changed")
    return_cut = np.quantile(quality["native_return"], [1 / 3, 2 / 3])
    return_group = ternary_labels(quality["native_return"], return_cut)
    np.savez_compressed(output / "cohort.npz", global_ids=ids, source=pairs[:, 0], source_episode=episodes)
    rows = []
    for axis, value in labels.items():
        joint = np.column_stack((pairs[:, 0], quality["final_success"], return_group,
                                 *[other for key, other in labels.items() if key != axis]))
        for level in (0, 2):
            target = value == level
            natural = float(target.mean())
            for change in changes:
                q = natural + change
                for name, strata in (("source_only", pairs[:, 0]), ("quality_cross_axis", joint)):
                    row = dict(axis=axis, level=level, control=name, natural_fraction=natural,
                               requested_change=change, requested_fraction=q, request_not_clipped=True)
                    try:
                        probabilities, weighted = stratified_probabilities(strata, target, q)
                        indices, fixed = fixed_stratified_indices(strata, target, q, data_seed + len(rows))
                    except ValueError as error:
                        row.update(feasible=False, reason=str(error))
                        rows.append(row)
                        continue
                    dose = f"{change:+.2f}" if change == round(change, 2) else f"{change:+.12g}"
                    key = f"{axis}_level{level}_{name}_delta{dose}"
                    path = output / (key + ".npz")
                    np.savez_compressed(path, episode_probabilities=probabilities, indices=indices)
                    counts = np.bincount(indices, minlength=total)
                    actual_sources = np.bincount(pairs[indices, 0], minlength=2)
                    if not np.array_equal(actual_sources, quota):
                        raise ValueError("Actual fixed-size source quotas changed")
                    if abs(target[indices].mean() - round(total * q) / total) > 1e-12:
                        raise ValueError("Actual global integer target count changed")
                    row.update(feasible=True, weighted=weighted, fixed=fixed, manifest=path.name,
                        manifest_sha256=sha256(path), observed_change=float(target[indices].mean() - natural),
                        source_counts=actual_sources.tolist(), repeated_copies=int(total - (counts > 0).sum()),
                        quality_fixed={key: numeric_summary(value[indices]) for key, value in quality.items()},
                        quality_weighted={key: numeric_summary(value, probabilities) for key, value in quality.items()})
                    rows.append(row)
    report = dict(task=task, data_seed=data_seed, expert_fraction=expert_fraction, total_episodes=total,
        source_label_artifact_sha256=sha256(labels_path), cohort_global_ids_sha256=hashlib.sha256(ids.tobytes()).hexdigest(),
        reference_disjoint=True, source_counts=quota.tolist(), return_thresholds=return_cut.tolist(),
        baseline_quality={key: numeric_summary(value) for key, value in quality.items()},
        baseline_category_counts={key: np.bincount(value, minlength=3).tolist() for key, value in labels.items()},
        candidate_controls=rows, requested=len(rows), feasible=sum(row["feasible"] for row in rows),
        loader_views_verified=0, final_scientific_matrix_frozen=False, performance_results_used=False,
        created=stamp(), code_sha256=sha256(Path(__file__)),
        limitation="Measured joint categories are balanced; continuous quality, goal heading and all state/goal occupancy are not held invariant")
    write_json(output / "audit.json", report)
    for row in rows:
        if row["feasible"]:
            for arm in ("weighted", "fixed_size"):
                load_control_selection(output / "cohort.npz", output / row["manifest"], labels_path, arm, task, data_seed)
                report["loader_views_verified"] += 1
    write_json(output / "audit.json", report)
    return report


def common_amplitude(reports, candidates=(.15, .10, .05), control="quality_cross_axis"):
    if not reports:
        raise ValueError("No cohort audits")
    for magnitude in candidates:
        valid = True
        for report in reports:
            rows = [row for row in report["candidate_controls"] if row.get("control", control) == control]
            groups = {(row.get("axis"), row.get("level")) for row in rows}
            for axis, level in groups:
                for sign in (-1, 1):
                    matches = [row for row in rows if row.get("axis") == axis and row.get("level") == level and
                               np.isclose(row["requested_change"], sign * magnitude, atol=1e-12, rtol=0)]
                    valid &= len(matches) == 1 and matches[0]["feasible"]
            valid &= bool(groups)
        if valid:
            return float(magnitude)
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--measurements", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    primary, summaries = [], []
    for mixture in (.25, .5, .75):
        for task in ("FetchPush", "PointMaze"):
            for data_seed in (1011, 1029, 1047):
                folder = args.output / f"mixture_{round(100 * mixture)}" / f"{task}_d{data_seed}"
                report = build_cohort(args.measurements / f"labels_{task}.npz", folder, task, data_seed,
                                      expert_fraction=mixture)
                summaries.append({key: report[key] for key in ("task", "data_seed", "expert_fraction", "requested", "feasible", "loader_views_verified")})
                if mixture == .5:
                    primary.append(report)
                print(json.dumps(summaries[-1]), flush=True)
    summary = dict(created=stamp(), reports=summaries, performance_results_used=False,
                   common_primary_quality_matched_amplitude=common_amplitude(primary),
                   common_primary_source_only_amplitude=common_amplitude(primary, control="source_only"),
                   dose_selection="Largest prespecified common feasible magnitude across BOTH signs, all six original type groups and all three primary cohorts/tasks; no policy outcome used",
                   final_scientific_matrix_frozen=False)
    write_json(args.output / "summary.json", summary)


if __name__ == "__main__":
    main()
